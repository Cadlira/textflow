// Gera Divergências.md. Uso: node gen-divergencias.js <codigo> [baseDir]
const fs = require('fs');
const code = (process.argv[2] || '').toLowerCase();
if (!code) { console.error('uso: node gen-divergencias.js <codigo>'); process.exit(1); }
const BASE = process.argv[3] || 'C:/Workspace-Pessoal/Certificacoes';
const OUT = `${BASE}/${code.toUpperCase()}`;
const qs = JSON.parse(fs.readFileSync(`${OUT}/_work/questions.json`, 'utf8'));
function fmt(q, a) {
  if (!a) return '—';
  switch (q.tipo) {
    case 'marcar_uma': return a.letra || '—';
    case 'multipla': return (a.letras || []).join(', ') || '—';
    case 'sim_nao': return a.valor || '—';
    case 'verdadeiro_falso': return (q.afirmacoes || []).map((af, i) => `(${i + 1}) ${a.afirmacoes && a.afirmacoes[af.id] === true ? 'Yes' : (a.afirmacoes && a.afirmacoes[af.id] === false ? 'No' : '?')}`).join(' ');
    case 'select': case 'arrastar': return Object.entries(a.selecoes || a.mapeamento || {}).map(([k, v]) => `${k}→${v}`).join('; ');
    case 'hotspot_imagem': return a.hotspot || '—';
    default: return JSON.stringify(a);
  }
}
const div = qs.filter(q => q.concordante === false);
let md = `# Divergências — ${code.toUpperCase()} (${new Date().toISOString().slice(0, 10)})\n\n> Questões em que a resposta dos agentes difere do gabarito do site.\n\n`;
if (!div.length) md += `Nenhuma divergência — os agentes concordaram com o gabarito do site nas ${qs.length} questões.\n`;
else {
  md += `| # (seq) | Tipo | Resposta do site | Resposta correta (IA) | Justificativa | Fontes |\n|---|---|---|---|---|---|\n`;
  for (const q of div) md += `| ${q.seq} | ${q.tipo} | ${fmt(q, q.resposta_site)} | ${fmt(q, q.resposta_correta)} | ${(q.justificativa_pt || '').replace(/\n/g, ' ').replace(/\|/g, '\\|')} | ${(q.fontes || []).map(f => `[link](${f})`).join('<br>')} |\n`;
  md += `\n**Total:** ${div.length} de ${qs.length}.\n`;
}
fs.writeFileSync(`${OUT}/Divergências.md`, md, 'utf8');
console.log('Divergências.md:', div.length, 'divergência(s):', div.map(q => q.seq).join(', ') || 'nenhuma');
