# tools/ — pipeline reutilizável (qualquer certificação)

Scripts **parametrizados pelo código do exame** que materializam o conhecimento da skill (não
dependem de uma sessão). Todos aceitam `<codigo>` (ex.: `ab-730`) e opcionalmente um `baseDir`
(default `C:/Workspace-Pessoal/Certificacoes`). Saída em `<baseDir>/<CODIGO>/`.

Pré-requisitos (uma vez por máquina):
- **Playwright** (biblioteca Node): `npm i -g playwright` **ou** `npm i playwright` em qualquer
  pasta — o `collect.js` resolve sozinho, nesta ordem: `PLAYWRIGHT_PATH` (override opcional) →
  `node_modules` local/ancestral → instalação global (`npm root -g`) → caminho legado
  (`C:/Workspace-Pessoal/NovoProjeto/node_modules`). **Não** precisa baixar navegadores
  (`npx playwright install` é desnecessário): a conexão é via CDP no Chrome do sistema.
- **python-docx**: `pip install python-docx` (para os Word).
- Chrome do sistema aberto com depuração + perfil persistente, **logado** no secexams:
  `chrome.exe --remote-debugging-port=9222 --user-data-dir=C:\Workspace-Pessoal\Certificacoes\.playwright-profile https://www.secexams.com/exams/Microsoft/<codigo>/view/`

Ordem do pipeline:
1. **Coleta** (todas as páginas, segue "Next Questions", baixa imagens):
   `node tools/collect.js <codigo>`  → `<CODIGO>/_work/questions.json` + `progress.json` + `<CODIGO>/simulado/img/`
   - **Checkpoint:** `progress.json` é gravado após **cada página**; sem flags, a coleta **retoma**
     de `proxima_pagina` (não recoleta páginas concluídas).
   - **`seq` determinístico:** `seq = (pagina - 1) * 50 + posição visual` (recoletar página
     intermediária não desloca a numeração).
   - **Anti-sobrescrita:** com dados **verificados** e coleta concluída, o comando **aborta**.
     `--page <n>` recoleta só a página n (aborta se ela tiver verificação); `--force` recoleta
     **preservando** verificação/traduções quando `seq`+`numero` coincidem;
     `--force --discard-verified` descarta verificação/traduções.
   - **Imagens:** baixa do S3 direto; se falhar (403/CORS), faz fallback via `fetch` no contexto da página (cookies).
2. **Verificação em dois estágios** (ver `references/revisao-e-failpoints.md`):
   - `especialista-certificacao` gera `_work/especialista-brief.md` (1×, âncora).
   - `pesquisador-verificador` em **lotes de ~18** ancorados no brief, gravando
     `_work/verdicts-exame-<inicio>-<fim>.json` (zero-pad, ex.: `verdicts-exame-001-018.json`).
   - Questões sem `muito_alta`+`concordante:true`: `pesquisador-documentacao-produto` (sem ver o
     gabarito do site) grava `_work/verdicts-produto-<inicio>-<fim>.json`.
   - Divergências/conflitos/baixa confiança: orquestrador roda `the-fool` (fallback
     `devils-advocate`; thread principal → `_work/the-fool-critique.md`) e a `mesa-decisao`
     (frio) grava `_work/verdicts-mesa.json`.
3. **Consenso** (quando o 1º verificador não fechou `muito_alta`+`concordante:true`):
   `node tools/compare-verdicts.js <codigo>`  → compara `verdicts-exame-*` × `verdicts-produto-*`,
   gera `_work/analises-consenso.json` (auditoria), `verdicts-consenso-*.json` (aceitos) e a lista
   de questões para a mesa.
4. **Merge**: `node tools/merge.js <codigo>`  → consolida os verdicts no `questions.json` com
   **precedência explícita** `mesa > consenso > produto > exame > legado` (`verdicts-mesa.json`
   sempre por último; `revisada_mesa:true` nunca é sobrescrito por nível inferior; loga a ordem
   real de aplicação, conflitos entre veredictos, questões que acionaram o 2º agente e as revisadas
   pela mesa). Aplica `_work/casos.json` (estudos de caso) quando existir.
5. **Tradução (gate)**: o `tradutor-ptbr` gera `_work/traducoes-*.json`; depois
   `node tools/apply-traducoes.js <codigo>` aplica (sem tocar respostas/veredictos) e
   `node tools/validate-ptbr.js <codigo>` **bloqueia** Word/simulado se faltar `*_pt`.
6. **Word**: `python tools/gen-word.py <codigo>`  → `Questões.docx`, `Sim ou Não.docx`,
   `Verdadeiro ou Falso.docx`, `Arrastar e Combobox.docx`, `Estudo de caso - <Nome>.docx`
   (com `opcoes_img` antes da transcrição nos tipos visuais).
7. **Divergências**: `node tools/gen-divergencias.js <codigo>`  → `Divergências.md`.
8. **Simulado**: `node tools/build-simulado.js <codigo>`  → copia o **template único**
   (`references/simulado-template.html`) + **Chart.js** (`tools/vendor/`) e gera `simulado-data.js`.
   (`--smoke` usa o gabarito do site como resposta provisória, só para testar a UI.)

> O **layout do simulado é SEMPRE o mesmo** para qualquer certificação: `build-simulado.js` copia
> `references/simulado-template.html` **verbatim**. Só o `simulado-data.js` (+ `img/`) muda.
> Para evoluir o layout, edite **o template na skill** — vale para todos os exames.

Esquema dos dados: `references/esquema-dados.md`. Contrato do `window.SIMULADO`: `references/simulado-spec.md`.
Seletores do secexams: `references/operacao-site.md`.
