// GATE de tradução: reprova (exit 1) se faltar PT-BR em campo exibido ao usuário.
// Uso: node validate-ptbr.js <codigo> [baseDir]
// Regra: todo campo *_en não-vazio exibido ao usuário precisa do par *_pt; justificativa_pt
// é obrigatória em TODAS as questões. Rodar ANTES de gen-word.py e build-simulado.js.
const fs = require('fs');
const code = (process.argv[2] || '').toLowerCase();
if (!code) { console.error('uso: node validate-ptbr.js <codigo> (ex.: ab-730)'); process.exit(1); }
const BASE = process.argv[3] || 'C:/Workspace-Pessoal/Certificacoes';
const WORK = `${BASE}/${code.toUpperCase()}/_work`;
const qs = JSON.parse(fs.readFileSync(WORK + '/questions.json', 'utf8'));

const has = s => typeof s === 'string' && s.trim().length > 0;
const issues = []; // {seq, campo}
const add = (seq, campo) => issues.push({ seq, campo });

for (const q of qs) {
  if (has(q.enunciado_en) && !has(q.enunciado_pt)) add(q.seq, 'enunciado_pt');
  if (has(q.contexto_en) && !has(q.contexto_pt)) add(q.seq, 'contexto_pt');
  if (!has(q.justificativa_pt)) add(q.seq, 'justificativa_pt');
  for (const [arr, en, pt] of [[q.opcoes, 'texto_en', 'texto_pt'], [q.afirmacoes, 'texto_en', 'texto_pt'],
                               [q.banco_opcoes, 'texto_en', 'texto_pt'], [q.alvos, 'rotulo_en', 'rotulo_pt'],
                               [q.hotspots, 'rotulo_en', 'rotulo_pt']]) {
    for (const item of (arr || [])) if (has(item[en]) && !has(item[pt])) add(q.seq, `${pt}(${item.id})`);
  }
}

const porCampo = {};
issues.forEach(i => { const k = i.campo.replace(/\(.*\)/, ''); porCampo[k] = (porCampo[k] || 0) + 1; });
if (issues.length) {
  console.error(`REPROVADO: ${issues.length} campo(s) PT-BR ausente(s) em ${new Set(issues.map(i => i.seq)).size} questão(ões).`);
  console.error('Resumo por campo:', JSON.stringify(porCampo));
  const bySeq = {};
  issues.forEach(i => { (bySeq[i.seq] = bySeq[i.seq] || []).push(i.campo); });
  for (const seq of Object.keys(bySeq).map(Number).sort((a, b) => a - b))
    console.error(`  seq ${seq}: ${bySeq[seq].join(', ')}`);
  console.error('Rode o tradutor-ptbr para os lotes pendentes e aplique com apply-traducoes.js antes de gerar Word/simulado.');
  process.exit(1);
}
console.log(`APROVADO: PT-BR completo nas ${qs.length} questões (enunciado, opções, afirmações, alvos, banco, contexto, hotspots e justificativa).`);
