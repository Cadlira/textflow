// Aplica _work/traducoes-*.json no questions.json (SOMENTE campos *_pt de exibição).
// Uso: node apply-traducoes.js <codigo> [baseDir]
// Garantia: NUNCA altera resposta_correta, resposta_site, concordante, confianca,
// revisada_mesa, justificativa_pt ou fontes (tradução não muda decisão).
const fs = require('fs');
const code = (process.argv[2] || '').toLowerCase();
if (!code) { console.error('uso: node apply-traducoes.js <codigo> (ex.: ab-730)'); process.exit(1); }
const BASE = process.argv[3] || 'C:/Workspace-Pessoal/Certificacoes';
const WORK = `${BASE}/${code.toUpperCase()}/_work`;
const qs = JSON.parse(fs.readFileSync(WORK + '/questions.json', 'utf8'));
const bySeq = {}; qs.forEach(q => bySeq[String(q.seq)] = q);

const files = fs.readdirSync(WORK).filter(f => /^traducoes-.*\.json$/.test(f)).sort();
if (!files.length) { console.error('Nenhum _work/traducoes-*.json encontrado — rode o tradutor-ptbr antes.'); process.exit(1); }
console.log('Arquivos de tradução:', files.join(', '));

// listas por id: aplica apenas o campo *_pt indicado
function mergePt(targetArr, srcArr, field) {
  if (!Array.isArray(targetArr) || !Array.isArray(srcArr)) return 0;
  const by = {}; srcArr.forEach(o => { if (o && o.id != null) by[o.id] = o; });
  let n = 0;
  for (const t of targetArr) {
    const s = by[t.id];
    if (s && typeof s[field] === 'string' && s[field].trim()) { t[field] = s[field]; n++; }
  }
  return n;
}

let applied = 0, fields = 0; const unknown = new Set(); const semQuestao = [];
const ALLOWED = new Set(['enunciado_pt', 'contexto_pt', 'opcoes', 'afirmacoes', 'alvos', 'banco_opcoes', 'hotspots']);
for (const f of files) {
  let t;
  try { t = JSON.parse(fs.readFileSync(WORK + '/' + f, 'utf8')); }
  catch (e) { console.error('JSON inválido', f, e.message); process.exitCode = 1; continue; }
  for (const seq of Object.keys(t)) {
    const q = bySeq[seq]; const d = t[seq];
    if (!q) { semQuestao.push(seq); continue; }
    for (const k of Object.keys(d)) if (!ALLOWED.has(k)) unknown.add(k);
    if (typeof d.enunciado_pt === 'string' && d.enunciado_pt.trim()) { q.enunciado_pt = d.enunciado_pt; fields++; }
    if (typeof d.contexto_pt === 'string' && d.contexto_pt.trim()) { q.contexto_pt = d.contexto_pt; fields++; }
    fields += mergePt(q.opcoes, d.opcoes, 'texto_pt');
    fields += mergePt(q.afirmacoes, d.afirmacoes, 'texto_pt');
    fields += mergePt(q.alvos, d.alvos, 'rotulo_pt');
    fields += mergePt(q.banco_opcoes, d.banco_opcoes, 'texto_pt');
    fields += mergePt(q.hotspots, d.hotspots, 'rotulo_pt');
    applied++;
  }
}
fs.writeFileSync(WORK + '/questions.json', JSON.stringify(qs, null, 2));
console.log('Traduções aplicadas em', applied, 'questão(ões) |', fields, 'campo(s) *_pt preenchidos.');
if (unknown.size) console.warn('Campos IGNORADOS (não são de tradução):', [...unknown].join(', '));
if (semQuestao.length) console.warn('Seqs sem questão correspondente:', semQuestao.join(','));
console.log('Decisões intactas: resposta_correta/resposta_site/concordante/confianca/revisada_mesa/justificativa_pt/fontes não são tocadas por este script.');
