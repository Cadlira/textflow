// Mescla os verdicts-*.json no questions.json com PRECEDÊNCIA EXPLÍCITA.
// Uso: node merge.js <codigo> [baseDir]
// Precedência (do menor para o maior): legado < exame < produto < consenso < mesa.
//  - verdicts-mesa.json SEMPRE é aplicado por último e nunca é sobrescrito.
//  - Questões com revisada_mesa:true não têm campos de decisão sobrescritos por nível inferior.
//  - Se _work/casos.json existir, aplica caso/contexto às faixas de seq (estudos de caso).
const fs = require('fs');
const code = (process.argv[2] || '').toLowerCase();
if (!code) { console.error('uso: node merge.js <codigo> (ex.: ab-730)'); process.exit(1); }
const BASE = process.argv[3] || 'C:/Workspace-Pessoal/Certificacoes';
const WORK = `${BASE}/${code.toUpperCase()}/_work`;
const qs = JSON.parse(fs.readFileSync(WORK + '/questions.json', 'utf8'));

// ----- classificação dos arquivos por nível de precedência -----
const LEVELS = ['legado', 'exame', 'produto', 'consenso', 'mesa'];
function levelOf(f) {
  if (f === 'verdicts-mesa.json') return 'mesa';
  if (/^verdicts-consenso-.*\.json$/.test(f)) return 'consenso';
  if (/^verdicts-produto-.*\.json$/.test(f)) return 'produto';
  if (/^verdicts-exame-.*\.json$/.test(f)) return 'exame';
  return 'legado'; // formato antigo verdicts-NNN-NNN.json: tratado como exame com MENOR precedência
}
const files = fs.readdirSync(WORK).filter(f => /^verdicts-.*\.json$/.test(f))
  .sort((a, b) => LEVELS.indexOf(levelOf(a)) - LEVELS.indexOf(levelOf(b)) || a.localeCompare(b));
console.log('Ordem de aplicação (menor → maior precedência):');
files.forEach(f => console.log('  -', f, '[' + levelOf(f) + ']'));
if (!files.length) console.log('  (nenhum verdict encontrado)');

// campos de DECISÃO (protegidos quando revisada_mesa:true) e campos de CONTEÚDO
const DECISION = ['resposta_correta', 'concordante', 'confianca', 'revisada_mesa', 'justificativa_pt', 'fontes', 'resposta_site'];
const CONTENT = ['enunciado_pt', 'afirmacoes', 'alvos', 'banco_opcoes', 'opcoes_img', 'hotspots', 'tipo', 'tipo_interno', 'caso', 'contexto_en', 'contexto_pt'];

const bySeq = {}; for (const q of qs) bySeq[String(q.seq)] = q;
const mesaProtected = new Set(qs.filter(q => q.revisada_mesa === true).map(q => String(q.seq)));
const conflicts = []; const seenAnswer = {}; // seq -> { file, json }
const segundoAgente = new Set(); const viaMesa = new Set();
let applied = 0; const touched = new Set();

for (const f of files) {
  let v;
  try { v = JSON.parse(fs.readFileSync(WORK + '/' + f, 'utf8')); }
  catch (e) { console.error('JSON inválido', f, e.message); continue; }
  const lvl = levelOf(f);
  for (const seq of Object.keys(v)) {
    const q = bySeq[seq]; if (!q) continue;
    const d = v[seq];
    if (lvl === 'produto') segundoAgente.add(+seq);
    if (lvl === 'mesa') viaMesa.add(+seq);
    // relatório de conflitos entre veredictos (resposta_correta divergente entre arquivos)
    if (d.resposta_correta !== undefined && d.resposta_correta !== null) {
      const js = JSON.stringify(d.resposta_correta);
      if (seenAnswer[seq] && seenAnswer[seq].json !== js)
        conflicts.push({ seq: +seq, antes: seenAnswer[seq].file, depois: f, de: seenAnswer[seq].json, para: js });
      seenAnswer[seq] = { file: f, json: js };
    }
    const protectDecision = lvl !== 'mesa' && (mesaProtected.has(seq));
    const apply = (k) => { if (d[k] !== undefined && d[k] !== null) q[k] = d[k]; };
    for (const k of CONTENT) apply(k);
    if (!protectDecision) for (const k of DECISION) apply(k);
    if (Array.isArray(d.opcoes) && Array.isArray(q.opcoes)) { const by = {}; d.opcoes.forEach(o => by[o.id] = o); q.opcoes = q.opcoes.map(o => ({ ...o, texto_pt: by[o.id]?.texto_pt ?? o.texto_pt, texto_en: by[o.id]?.texto_en ?? o.texto_en })); }
    else if (Array.isArray(d.opcoes)) q.opcoes = d.opcoes;
    if (lvl === 'mesa') { q.revisada_mesa = true; mesaProtected.add(seq); }
    touched.add(seq); applied++;
  }
}

// ----- fallback de estudos de caso: _work/casos.json (faixas de seq) -----
if (fs.existsSync(WORK + '/casos.json')) {
  try {
    const casos = JSON.parse(fs.readFileSync(WORK + '/casos.json', 'utf8'));
    for (const nome of Object.keys(casos)) {
      const c = casos[nome]; let n = 0;
      for (const q of qs) if (q.seq >= c.seq_inicio && q.seq <= c.seq_fim) {
        q.caso = nome;
        if (c.contexto_en && !q.contexto_en) q.contexto_en = c.contexto_en;
        if (c.contexto_pt && !q.contexto_pt) q.contexto_pt = c.contexto_pt;
        n++;
      }
      console.log('casos.json:', nome, '→ seq', c.seq_inicio + '-' + c.seq_fim, '(' + n + ' questões)');
    }
  } catch (e) { console.error('casos.json inválido:', e.message); }
}

fs.writeFileSync(WORK + '/questions.json', JSON.stringify(qs, null, 2));
const missing = qs.filter(q => !touched.has(String(q.seq))).map(q => q.seq);
const div = qs.filter(q => q.concordante === false).map(q => q.seq);
const noTruth = qs.filter(q => !q.resposta_correta).map(q => q.seq);
console.log('Aplicados', applied, 'registros |', touched.size, '/', qs.length, 'questões | sem verdict:', missing.join(',') || 'nenhuma');
console.log('Acionaram 2º agente (produto):', [...segundoAgente].sort((a, b) => a - b).join(',') || 'nenhuma');
console.log('Revisadas pela mesa:', [...viaMesa].sort((a, b) => a - b).join(',') || 'nenhuma');
if (conflicts.length) {
  console.log('CONFLITOS entre veredictos (resolvidos pela precedência):');
  conflicts.forEach(c => console.log(`  seq ${c.seq}: ${c.antes} ${c.de} → ${c.depois} ${c.para}`));
} else console.log('Conflitos entre veredictos: nenhum');
console.log('Divergências:', div.join(',') || 'nenhuma', '| sem resposta_correta:', noTruth.join(',') || 'nenhuma');
