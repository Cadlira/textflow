// Monta o simulado: copia o TEMPLATE ÚNICO + Chart.js, e gera simulado-data.js (normalizado).
// Uso: node build-simulado.js <codigo> [baseDir] [--smoke] [--verified-only]
//   --verified-only: inclui só questões com resposta_correta (útil enquanto faltam páginas verificadas)
// O template e o Chart.js vêm da PRÓPRIA skill (iguais para qualquer certificação).
const fs = require('fs'); const path = require('path');
const code = (process.argv[2] || '').toLowerCase();
if (!code) { console.error('uso: node build-simulado.js <codigo> [baseDir] [--smoke] [--verified-only]'); process.exit(1); }
const SMOKE = process.argv.includes('--smoke');
const VONLY = process.argv.includes('--verified-only');
const BASE = (process.argv[3] && !process.argv[3].startsWith('--')) ? process.argv[3] : 'C:/Workspace-Pessoal/Certificacoes';
const OUT = `${BASE}/${code.toUpperCase()}`;
const SIM = `${OUT}/simulado`;
const TEMPLATE = path.join(__dirname, '..', 'references', 'simulado-template.html');
const VENDOR = path.join(__dirname, 'vendor', 'chart.umd.min.js');
const qsAll = JSON.parse(fs.readFileSync(`${OUT}/_work/questions.json`, 'utf8'));
// fallback de estudos de caso: _work/casos.json aplica caso/contexto por faixa de seq (em memória)
const CASOS = `${OUT}/_work/casos.json`;
if (fs.existsSync(CASOS)) {
  try {
    const casos = JSON.parse(fs.readFileSync(CASOS, 'utf8'));
    for (const nome of Object.keys(casos)) {
      const c = casos[nome];
      for (const q of qsAll) if (q.seq >= c.seq_inicio && q.seq <= c.seq_fim) {
        q.caso = nome;
        if (c.contexto_en && !q.contexto_en) q.contexto_en = c.contexto_en;
        if (c.contexto_pt && !q.contexto_pt) q.contexto_pt = c.contexto_pt;
      }
      console.log('casos.json aplicado:', nome, 'seq', c.seq_inicio + '-' + c.seq_fim);
    }
  } catch (e) { console.error('casos.json inválido:', e.message); }
}
const qs = VONLY ? qsAll.filter(q => q.resposta_correta) : qsAll;
const pe = (en, pt) => ({ en: en || pt || '', pt: pt || en || '' });
// bbox: só repassa o formato RELATIVO ({x,y,w,h,unit:"relative"}, valores 0..1).
// Formato legado em pixels ([x,y,w,h]) é descartado → o template usa fallback por botões.
const relBbox = b => (b && typeof b === 'object' && !Array.isArray(b) && b.unit === 'relative'
  && [b.x, b.y, b.w, b.h].every(v => typeof v === 'number' && v >= 0 && v <= 1)) ? { x: b.x, y: b.y, w: b.w, h: b.h, unit: 'relative' } : undefined;

const questoes = qs.map(q => {
  const o = {
    seq: q.seq, numero: q.numero, tipo: q.tipo, caso: q.caso || null,
    contexto: (q.contexto_en || q.contexto_pt) ? pe(q.contexto_en, q.contexto_pt) : null,
    enunciado: pe(q.enunciado_en, q.enunciado_pt),
    enunciadoImg: q.enunciado_img || null, opcoesImg: q.opcoes_img || null, respSiteImg: q.resposta_site_img || null,
    correta: q.resposta_correta || (SMOKE ? q.resposta_site : null), site: q.resposta_site || null,
    concordante: q.concordante, confianca: q.confianca || null,
    motivo: q.justificativa_pt || (SMOKE ? '(smoke)' : ''), fontes: q.fontes || []
  };
  if (Array.isArray(q.opcoes)) o.opcoes = q.opcoes.map(x => ({ id: x.id, en: x.texto_en || '', pt: x.texto_pt || x.texto_en || '' }));
  if (Array.isArray(q.afirmacoes)) o.afirmacoes = q.afirmacoes.map(x => ({ id: x.id, en: x.texto_en || '', pt: x.texto_pt || x.texto_en || '' }));
  if (Array.isArray(q.alvos)) o.alvos = q.alvos.map(x => ({ id: x.id, en: x.rotulo_en || '', pt: x.rotulo_pt || x.rotulo_en || '' }));
  if (Array.isArray(q.banco_opcoes)) o.banco = q.banco_opcoes.map((x, i) => ({ id: x.id || ('o' + (i + 1)), en: x.texto_en || '', pt: x.texto_pt || x.texto_en || '' }));
  if (Array.isArray(q.hotspots)) o.hotspots = q.hotspots.map(h => { const out = { id: h.id, pt: h.rotulo_pt || h.id, en: h.rotulo_en || h.id }; const bb = relBbox(h.bbox); if (bb) out.bbox = bb; return out; });
  // normaliza id de opção do banco → texto EN (a correção compara texto EN); aceita valor único ou LISTA (arrastar)
  const toEn = v => { const hit = (o.banco || []).find(b => b.id === v); return hit ? hit.en : v; };
  const normVal = v => Array.isArray(v) ? v.map(toEn) : toEn(v);
  const normSel = m => { if (!m) return m; const r = {}; for (const k in m) r[k] = normVal(m[k]); return r; };
  if (q.tipo === 'select' || q.tipo === 'arrastar') {
    for (const t of ['correta', 'site']) {
      if (o[t] && o[t].selecoes) o[t].selecoes = normSel(o[t].selecoes);
      if (o[t] && o[t].mapeamento) o[t].mapeamento = normSel(o[t].mapeamento);
    }
  }
  const c = o.correta || {};
  o.autograde = (() => { switch (q.tipo) {
    case 'marcar_uma': return !!(o.opcoes && c.letra);
    case 'multipla': return !!(o.opcoes && c.letras && c.letras.length);
    case 'sim_nao': return !!(o.opcoes && c.valor);
    case 'verdadeiro_falso': return !!(o.afirmacoes && o.afirmacoes.length && c.afirmacoes);
    case 'select': return !!(o.alvos && o.banco && c.selecoes);
    case 'arrastar': return !!(o.alvos && o.banco && c.mapeamento);
    case 'hotspot_imagem': return !!(o.hotspots && o.hotspots.length && c.hotspot);
    default: return false; } })();
  return o;
});

fs.mkdirSync(`${SIM}/vendor`, { recursive: true }); fs.mkdirSync(`${SIM}/img`, { recursive: true });
// 1) TEMPLATE ÚNICO (verbatim) + Chart.js (da skill)
fs.copyFileSync(TEMPLATE, `${SIM}/simulado.html`);
fs.copyFileSync(VENDOR, `${SIM}/vendor/chart.umd.min.js`);
// 2) dados normalizados
fs.writeFileSync(`${SIM}/simulado-data.js`, 'window.SIMULADO = ' + JSON.stringify({ codigo: code.toUpperCase(), geradoEm: new Date().toISOString(), questoes }, null, 1) + ';\n');
console.log((SMOKE ? '[SMOKE] ' : '') + 'simulado pronto em', SIM, '|', questoes.length, 'questões | autograde:', questoes.filter(x => x.autograde).length, '| fallback:', questoes.filter(x => !x.autograde).length);
console.log('Template copiado verbatim da skill (único p/ qualquer certificação).');
