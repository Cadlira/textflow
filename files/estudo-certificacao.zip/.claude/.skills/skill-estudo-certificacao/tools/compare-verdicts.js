// Comparador DETERMINÍSTICO de consenso entre os dois verificadores.
// Uso: node compare-verdicts.js <codigo> [baseDir]
// Lê _work/verdicts-exame-*.json (1º agente) e _work/verdicts-produto-*.json (2º agente) e:
//   - compara resposta_correta ESTRUTURADA por tipo (sem semântica; ambiguidade → mesa);
//   - gera _work/analises-consenso.json (auditoria interna — NUNCA vai para questions.json);
//   - gera _work/verdicts-consenso-<inicio>-<fim>.json com os casos aceitos por consenso;
//   - lista as questões que DEVEM ir para a mesa (the-fool/devils-advocate + mesa-decisao).
// Confiança final (regra fixa):
//   - dois agentes concordam e AMBOS têm fonte oficial direta (learn.microsoft.com) → muito_alta
//   - concordam e só UM tem fonte oficial direta → alta
//   - concordam sem fonte direta (apoio/raciocínio) → media
//   - rebaixamento: as duas confianças individuais baixas → baixa (vai à mesa); uma baixa → no máx. media
//   - discordam OU estrutura incompatível/incompleta → mesa
//   - consenso DIVERGENTE do site NUNCA é aceito direto → mesa (regra global da skill)
// Não pesquisa web. Não substitui a mesa.
const fs = require('fs');
const code = (process.argv[2] || '').toLowerCase();
if (!code) { console.error('uso: node compare-verdicts.js <codigo> (ex.: ab-730)'); process.exit(1); }
const BASE = process.argv[3] || 'C:/Workspace-Pessoal/Certificacoes';
const WORK = `${BASE}/${code.toUpperCase()}/_work`;
const qs = JSON.parse(fs.readFileSync(WORK + '/questions.json', 'utf8'));
const byType = {}; qs.forEach(q => byType[String(q.seq)] = q);

function loadSet(prefix) {
  const out = {};
  for (const f of fs.readdirSync(WORK).filter(x => new RegExp(`^verdicts-${prefix}-.*\\.json$`).test(x)).sort()) {
    try { Object.assign(out, JSON.parse(fs.readFileSync(WORK + '/' + f, 'utf8'))); }
    catch (e) { console.error('JSON inválido', f, e.message); }
  }
  return out;
}
const exame = loadSet('exame');
const produto = loadSet('produto');

const norm = s => (s == null ? '' : String(s)).trim().toLowerCase();
const yn = v => v === true ? 'yes' : (v === false ? 'no' : norm(v));
const asList = v => Array.isArray(v) ? v : (v == null ? [] : [v]);
const msEq = (a, b) => { const A = asList(a).map(norm).sort(); const B = asList(b).map(norm).sort(); return A.length === B.length && A.every((x, i) => x === B[i]); };

// equivalência estrutural por tipo: true | false | null (estrutura incompatível/incompleta)
function equivalent(tipo, a, b) {
  if (!a || !b || typeof a !== 'object' || typeof b !== 'object') return null;
  switch (tipo) {
    case 'marcar_uma': if (!a.letra || !b.letra) return null; return norm(a.letra) === norm(b.letra);
    case 'multipla': if (!Array.isArray(a.letras) || !Array.isArray(b.letras) || !a.letras.length || !b.letras.length) return null; return msEq(a.letras, b.letras);
    case 'sim_nao': if (!a.valor || !b.valor) return null; return yn(a.valor) === yn(b.valor);
    case 'verdadeiro_falso': {
      if (!a.afirmacoes || !b.afirmacoes) return null;
      const ka = Object.keys(a.afirmacoes), kb = Object.keys(b.afirmacoes);
      if (!ka.length || ka.length !== kb.length) return null;
      return ka.every(k => k in b.afirmacoes && yn(a.afirmacoes[k]) === yn(b.afirmacoes[k]));
    }
    case 'select': {
      const sa = a.selecoes || a.mapeamento, sb = b.selecoes || b.mapeamento;
      if (!sa || !sb) return null; const ka = Object.keys(sa);
      if (!ka.length || ka.length !== Object.keys(sb).length) return null;
      return ka.every(k => k in sb && msEq(sa[k], sb[k]));
    }
    case 'arrastar': {
      const sa = a.mapeamento || a.selecoes, sb = b.mapeamento || b.selecoes;
      if (!sa || !sb) return null; const ka = Object.keys(sa);
      if (!ka.length || ka.length !== Object.keys(sb).length) return null;
      return ka.every(k => k in sb && msEq(sa[k], sb[k]));
    }
    case 'hotspot_imagem': if (a.hotspot == null || b.hotspot == null) return null; return msEq(a.hotspot, b.hotspot);
    default: return null;
  }
}
const hasDirectOfficial = fontes => (fontes || []).some(u => /(?:^|\/\/)(?:[\w-]+\.)*learn\.microsoft\.com\//i.test(u) || /docs\.microsoft\.com\//i.test(u));
const isLow = c => ['baixa', 'muito_baixa'].includes(norm(c));

const analises = {}; const mesa = []; const aceitas = []; const pendentes2 = [];
const consensoOut = {};

// questões que deveriam ter acionado o 2º agente e ainda não têm verdict de produto
for (const seq of Object.keys(exame)) {
  const e = exame[seq];
  const altaConf = ['muito_alta', 'alta'].includes(norm(e.confianca));
  const direto = altaConf && e.concordante === true;
  const divergeDireto = altaConf && e.concordante === false;
  if (!direto && !divergeDireto && !produto[seq]) pendentes2.push(+seq);
  if (divergeDireto && !mesa.includes(+seq)) {
    mesa.push(+seq);
    analises[seq] = { exame: pick(e), produto: null, consenso: { status: 'sem_consenso_necessario', motivo: 'muito_alta porém concordante:false — divergência contra o site vai direto para the-fool + mesa', confianca_final: null, para_mesa: true } };
  }
}
function pick(v) { return v ? { resposta_correta: v.resposta_correta ?? null, confianca: v.confianca ?? null, concordante: (typeof v.concordante === 'boolean' ? v.concordante : null), fontes: v.fontes || [] } : null; }

for (const seq of Object.keys(produto)) {
  const p = produto[seq]; const e = exame[seq]; const q = byType[seq];
  const tipo = q ? q.tipo : null;
  const a = { exame: pick(e), produto: pick(p), consenso: {} };
  const c = a.consenso;
  if (!e) { c.status = 'incompleto'; c.motivo = 'sem veredito do agente de exame'; c.para_mesa = true; }
  else if (!q) { c.status = 'incompleto'; c.motivo = 'seq não existe em questions.json'; c.para_mesa = true; }
  else {
    const eq = equivalent(tipo, e.resposta_correta, p.resposta_correta);
    if (eq === null) { c.status = 'estrutura_incompativel'; c.motivo = 'resposta_correta ausente/estrutura incompatível com o tipo ' + tipo; c.para_mesa = true; }
    else if (eq === false) { c.status = 'conflito'; c.motivo = 'os dois agentes propõem respostas diferentes'; c.para_mesa = true; }
    else {
      c.status = 'concordam';
      const dE = hasDirectOfficial(e.fontes), dP = hasDirectOfficial(p.fontes);
      let conf = dE && dP ? 'muito_alta' : (dE || dP ? 'alta' : 'media');
      if (isLow(e.confianca) && isLow(p.confianca)) conf = 'baixa';
      else if ((isLow(e.confianca) || isLow(p.confianca)) && (conf === 'muito_alta' || conf === 'alta')) conf = 'media';
      c.confianca_final = conf;
      c.motivo = `fontes diretas: exame=${dE}, produto=${dP}; confianças individuais: ${e.confianca}/${p.confianca}`;
      // concordância com o site: usa o concordante do 1º agente (que comparou com o gabarito)
      const concSite = (typeof e.concordante === 'boolean') ? e.concordante : null;
      c.concordante_site = concSite;
      if (concSite === false) { c.para_mesa = true; c.motivo_mesa = 'consenso DIVERGENTE do gabarito do site — divergência nunca é aceita sem mesa'; }
      else if (concSite === null) { c.para_mesa = true; c.motivo_mesa = 'sem comparação confiável com o gabarito do site'; }
      else if (conf === 'baixa' || conf === 'muito_baixa') { c.para_mesa = true; c.motivo_mesa = 'confiança final baixa após consenso'; }
      else {
        c.para_mesa = false;
        consensoOut[seq] = {
          resposta_correta: e.resposta_correta, concordante: true, confianca: conf,
          justificativa_pt: e.justificativa_pt || p.justificativa_pt || null,
          fontes: [...new Set([...(e.fontes || []), ...(p.fontes || [])])]
        };
        aceitas.push(+seq);
      }
    }
  }
  if (c.para_mesa && !mesa.includes(+seq)) mesa.push(+seq);
  analises[seq] = a;
}

mesa.sort((x, y) => x - y); aceitas.sort((x, y) => x - y); pendentes2.sort((x, y) => x - y);
const doc = { codigo: code.toUpperCase(), geradoEm: new Date().toISOString(),
  resumo: { comparadas: Object.keys(produto).length, aceitas_por_consenso: aceitas.length, para_mesa: mesa.length, pendentes_segundo_agente: pendentes2.length },
  aceitas, mesa, pendentes_segundo_agente: pendentes2, questoes: analises };
fs.writeFileSync(WORK + '/analises-consenso.json', JSON.stringify(doc, null, 2));

if (aceitas.length) {
  const pad = n => String(n).padStart(3, '0');
  const fname = `verdicts-consenso-${pad(aceitas[0])}-${pad(aceitas[aceitas.length - 1])}.json`;
  fs.writeFileSync(WORK + '/' + fname, JSON.stringify(consensoOut, null, 2));
  console.log('Consenso aceito →', fname, '(' + aceitas.length + ' questões):', aceitas.join(','));
} else console.log('Nenhuma questão aceita por consenso.');
console.log('Para a MESA (the-fool/devils-advocate + mesa-decisao):', mesa.join(',') || 'nenhuma');
if (pendentes2.length) console.warn('PENDENTES do 2º agente (sem verdicts-produto e sem muito_alta):', pendentes2.join(','));
console.log('Auditoria interna em _work/analises-consenso.json (NÃO entra no questions.json).');
