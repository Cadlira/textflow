// Coletor GERAL do secexams (qualquer certificação Microsoft).
// Uso:
//   node collect.js <codigo> [baseDir]                         -> coleta o exame inteiro (retoma de progress.json se incompleto)
//   node collect.js <codigo> [baseDir] --page N                -> recoleta SÓ a página N (aborta se a página tem dados verificados)
//   node collect.js <codigo> [baseDir] --page N --force        -> força recoleta da página N, PRESERVANDO verificação quando seq+numero coincidem
//   node collect.js <codigo> [baseDir] --force                 -> recoleta tudo, PRESERVANDO verificação quando seq+numero coincidem
//   node collect.js <codigo> [baseDir] --force --discard-verified -> recoleta DESCARTANDO verificação/traduções anteriores
// seq é DETERMINÍSTICO por página: seq = (pagina - 1) * 50 + posição visual (1..50).
// progress.json é gravado após CADA página (retomada segura após queda/limite de tokens).
// Pré: Chrome aberto com --remote-debugging-port=9222 --user-data-dir=<perfil> e usuário LOGADO.
const args = process.argv.slice(2);
const flags = new Set(); let onlyPage = null; let pageSizeArg = null; const pos = [];
for (let i = 0; i < args.length; i++) { const a = args[i]; if (a === '--page') onlyPage = parseInt(args[++i], 10); else if (a === '--page-size') pageSizeArg = parseInt(args[++i], 10); else if (a.startsWith('--')) flags.add(a.slice(2)); else pos.push(a); }
const code = (pos[0] || '').toLowerCase();
if (!code) { console.error('uso: node collect.js <codigo> [baseDir] [--page N] [--page-size N] [--force] [--discard-verified]'); process.exit(1); }
const BASE = pos[1] || 'C:/Workspace-Pessoal/Certificacoes';
const FORCE = flags.has('force');
const DISCARD = flags.has('discard-verified');
// Tamanho de página do exame. Default 50 (ex.: ab-730). Alguns exames fixam outro valor (ex.:
// ab-100 = 5/pág, sem controle de itens-por-página). Definir via --page-size mantém o `seq`
// determinístico e CONTÍNUO: seq = (pagina-1)*PAGE_SIZE + posição visual.
const PAGE_SIZE = (Number.isInteger(pageSizeArg) && pageSizeArg > 0) ? pageSizeArg : 50;
// ---------- resolução automática do Playwright (nenhuma configuração obrigatória) ----------
// Ordem: PLAYWRIGHT_PATH (override opcional) → node_modules local/ancestral → instalação
// global do npm (npm root -g) → caminho legado. Não precisa baixar navegadores
// (npx playwright install é desnecessário): conectamos no Chrome do sistema via CDP.
function resolvePlaywright() {
  const cands = [];
  if (process.env.PLAYWRIGHT_PATH) cands.push(process.env.PLAYWRIGHT_PATH);
  cands.push('playwright');
  try { const g = require('child_process').execSync('npm root -g', { encoding: 'utf8' }).trim(); if (g) cands.push(g.replace(/\\/g, '/') + '/playwright'); } catch (e) {}
  cands.push('C:/Workspace-Pessoal/NovoProjeto/node_modules/playwright');
  for (const c of cands) { try { return require(c); } catch (e) {} }
  console.error('ERRO: biblioteca Playwright não encontrada.');
  console.error('Instale com "npm i -g playwright" (ou "npm i playwright" em qualquer pasta).');
  console.error('Caminhos tentados: ' + cands.join(' | '));
  console.error('Obs.: não é preciso baixar navegadores — o collect.js usa o Chrome do sistema via CDP.');
  process.exit(1);
}
const { chromium } = resolvePlaywright();
const fs = require('fs'); const https = require('https');
const OUT = `${BASE}/${code.toUpperCase()}`, IMG = `${OUT}/simulado/img`, WORK = `${OUT}/_work`;
const URLBASE = `https://www.secexams.com/exams/Microsoft/${code}/view/`;

function dlDirect(url, dest) { return new Promise((res, rej) => { const f = fs.createWriteStream(dest); https.get(url, r => { if (r.statusCode !== 200) { f.close(); fs.unlink(dest, () => {}); return rej(new Error('HTTP ' + r.statusCode)); } r.pipe(f); f.on('finish', () => f.close(() => res(true))); }).on('error', e => { f.close(); fs.unlink(dest, () => {}); rej(e); }); }); }
async function download(url, dest, page) { // fallback: fetch no contexto da página (cookies/CORS)
  try { await dlDirect(url, dest); }
  catch (e) { const arr = await page.evaluate(async u => { const r = await fetch(u, { credentials: 'include' }); const b = await r.arrayBuffer(); return Array.from(new Uint8Array(b)); }, url); fs.writeFileSync(dest, Buffer.from(arr)); }
}

// ---------- progress.json (checkpoint de retomada) ----------
function loadProgress() { try { return JSON.parse(fs.readFileSync(WORK + '/progress.json', 'utf8')); } catch (e) { return null; } }
function saveProgress(p) { p.atualizado_em = new Date().toISOString(); fs.writeFileSync(WORK + '/progress.json', JSON.stringify(p, null, 2)); }
function newProgress() {
  return { codigo: code.toUpperCase(), fase: 'coleta', status: 'em_andamento', paginas_coletadas: [], paginas_com_erro: [],
    ultima_pagina: 0, proxima_pagina: 1, page_size: PAGE_SIZE, ultimo_seq: 0, total_questoes: 0, url_base: URLBASE,
    tipos: {}, iniciado_em: new Date().toISOString(), atualizado_em: new Date().toISOString() };
}
function refreshProgress(p, all) {
  p.paginas_coletadas = [...new Set(all.map(q => q.pagina))].sort((a, b) => a - b);
  p.ultimo_seq = all.reduce((m, q) => Math.max(m, q.seq), 0);
  p.total_questoes = all.length;
  p.tipos = all.reduce((a, q) => { a[q.tipo] = (a[q.tipo] || 0) + 1; return a; }, {});
}

// ---------- preservação de verificação/traduções (quando seq + numero coincidem) ----------
const PRESERVE = ['resposta_correta', 'concordante', 'confianca', 'revisada_mesa', 'justificativa_pt', 'fontes',
  'enunciado_pt', 'contexto_en', 'contexto_pt', 'caso', 'tipo_interno', 'afirmacoes', 'alvos', 'banco_opcoes', 'hotspots'];
function preserveVerified(nq, oq) {
  for (const k of PRESERVE) {
    const v = oq[k];
    if (v === undefined || v === null) continue;
    if (Array.isArray(v) && !v.length) continue;
    nq[k] = v;
  }
  if (Array.isArray(nq.opcoes) && Array.isArray(oq.opcoes)) { // traduções das opções por id
    const by = {}; oq.opcoes.forEach(o => by[o.id] = o);
    nq.opcoes = nq.opcoes.map(o => ({ ...o, texto_pt: by[o.id]?.texto_pt ?? o.texto_pt }));
  }
  return nq;
}

const EXTRACT = () => {
  const cards = Array.from(document.querySelectorAll('div[id^="nav-question"]')).map(c => {
    const numero = (c.querySelector('h5')?.innerText || '').replace(/Question\s*#/, '').trim();
    const descEl = c.querySelector('.question-description');
    let enun = '';
    if (descEl) { const cl = descEl.cloneNode(true); cl.querySelectorAll('img').forEach(i => i.remove()); const t = document.createElement('div'); t.innerHTML = cl.innerHTML.replace(/<br\s*\/?>/gi, '\n'); enun = (t.innerText || t.textContent || '').trim(); }
    const descImg = descEl?.querySelector('img:not([src*="gpt.png"])');
    const lis = Array.from(c.querySelectorAll('ol.rounded-list > li'));
    const opcoes = lis.map(li => ({ id: (li.querySelector('.option-circle')?.innerText || '').trim(), texto_en: (li.querySelector('.option-text')?.innerText || '').trim(), correct: li.getAttribute('data-correct') === 'True' }));
    const ca = c.querySelector('.correct-answer'); const caImg = ca?.querySelector('img');
    return { numero, enun, enun_img_url: descImg ? descImg.src : null, opcoes, correct_img_url: caImg ? caImg.src : null, correctText: caImg ? null : (ca?.innerText || '').trim() };
  });
  const hasNext = Array.from(document.querySelectorAll('a')).some(a => /next questions/i.test(a.innerText || ''));
  return { cards, hasNext };
};

(async () => {
  fs.mkdirSync(IMG, { recursive: true }); fs.mkdirSync(WORK, { recursive: true });
  let existing = []; if (fs.existsSync(WORK + '/questions.json')) existing = JSON.parse(fs.readFileSync(WORK + '/questions.json', 'utf8'));
  const oldBySeq = {}; existing.forEach(q => oldBySeq[q.seq] = q);
  const hasVerified = existing.some(q => q.resposta_correta);
  const pageHasVerified = n => existing.some(q => q.pagina === n && q.resposta_correta);
  let progress = loadProgress();

  // ---------- guardas e modo de execução ----------
  let mode, startPage;
  if (onlyPage !== null) {
    if (!Number.isInteger(onlyPage) || onlyPage < 1) { console.error('ABORTADO: --page exige um número de página >= 1.'); process.exit(1); }
    if (pageHasVerified(onlyPage) && !FORCE) { console.error('ABORTADO: página ' + onlyPage + ' já tem respostas VERIFICADAS. Use --force (preserva verificação quando seq+numero coincidem) ou --force --discard-verified (descarta).'); process.exit(1); }
    mode = 'page'; startPage = onlyPage;
  } else if (FORCE) {
    mode = 'full'; startPage = 1;
    if (hasVerified && !DISCARD) console.log('Recoleta TOTAL: verificação será PRESERVADA quando seq+numero coincidirem (use --discard-verified para descartar).');
    if (hasVerified && DISCARD) console.log('Recoleta TOTAL: verificação/traduções anteriores serão DESCARTADAS (--discard-verified).');
  } else if (progress && progress.status !== 'concluido' && existing.length) {
    mode = 'resume'; startPage = progress.proxima_pagina || ((progress.ultima_pagina || 0) + 1) || 1;
    console.log('Retomando coleta do checkpoint: próxima página', startPage, '| já coletadas:', (progress.paginas_coletadas || []).join(',') || 'nenhuma');
  } else if (existing.length && hasVerified) {
    console.error('ABORTADO: questions.json já tem dados VERIFICADOS e a coleta consta como concluída. Use --page <n> para recoletar uma página, ou --force para recoletar tudo (preserva verificação quando seq+numero coincidem).');
    process.exit(1);
  } else if (existing.length) {
    mode = 'full'; startPage = 1;
    console.log('Dados existentes sem verificação: recoletando tudo.');
  } else { mode = 'full'; startPage = 1; }

  // progress: 'full' recomeça; 'resume' e 'page' reaproveitam o existente (page cria se não houver)
  if (mode === 'full' || !progress) progress = newProgress();

  const b = await chromium.connectOverCDP('http://localhost:9222');
  const page = await b.contexts()[0].newPage();
  // base de questões mantidas: página alvo sai (page mode); tudo sai (full); páginas coletadas ficam (resume)
  let all;
  if (mode === 'page') all = existing.filter(q => q.pagina !== onlyPage);
  else if (mode === 'resume') all = existing.slice();
  else all = [];
  const stats = { preservadas: [], substituidas: [], adicionadas: [] };

  let pg = startPage;
  try {
    while (pg <= 1000) { // cap de segurança (a parada real é o link "Next Questions" inexistente)
      await page.goto(URLBASE + pg, { waitUntil: 'load' }); await page.waitForTimeout(1000);
      const { cards, hasNext } = await page.evaluate(EXTRACT);
      if (!cards.length) break;
      const basePage = (pg - 1) * PAGE_SIZE; // seq determinístico por página e posição visual
      let posVis = 0;
      for (const d of cards) {
        posVis++; const seq = basePage + posVis;
        const nOpts = d.opcoes.length; const up = (d.enun || '').toUpperCase();
        let tipo;
        if (nOpts > 0) { const yn = nOpts <= 3 && d.opcoes.every(o => /^(yes|no)$/i.test(o.texto_en)); let cc = d.opcoes.filter(o => o.correct).length; if (!cc && d.correctText) cc = (d.correctText.match(/[A-Z]/g) || []).length; tipo = yn ? 'sim_nao' : (cc >= 2 ? 'multipla' : 'marcar_uma'); }
        else if (/DRAG\s+(AND\s+)?DROP/.test(up)) tipo = 'arrastar';
        else if (/SELECT YES IF THE STATEMENT/.test(up)) tipo = 'verdadeiro_falso';
        else if (/COMPLETES THE SENTENCE/.test(up)) tipo = 'select';
        else tipo = 'hotspot_imagem';
        let eimg = null, rimg = null;
        if (d.enun_img_url) { eimg = 'img/q' + seq + '-enunciado.png'; try { await download(d.enun_img_url, IMG + '/q' + seq + '-enunciado.png', page); } catch (e) { console.error('img enun q' + seq, e.message); eimg = null; } }
        if (d.correct_img_url) { rimg = 'img/q' + seq + '-resposta.png'; try { await download(d.correct_img_url, IMG + '/q' + seq + '-resposta.png', page); } catch (e) { console.error('img resp q' + seq, e.message); rimg = null; } }
        let rs = null;
        if (nOpts > 0) { let L = d.opcoes.filter(o => o.correct).map(o => o.id); if (!L.length && d.correctText) L = (d.correctText.match(/[A-Z]/g) || []); rs = tipo === 'multipla' ? { letras: L } : (tipo === 'sim_nao' ? { valor: (d.opcoes.find(o => o.correct)?.texto_en || '') } : { letra: L[0] || '' }); }
        // Estudo de caso: quando o secexams expuser caso/contexto no DOM (mapear seletor na
        // análise ao vivo — operacao-site.md), preencher d.caso/d.contexto_en no EXTRACT e
        // repassar aqui. Fallback suportado: _work/casos.json (faixas de seq) aplicado pelo
        // merge.js/build-simulado.js.
        const q = { seq, numero: d.numero, pagina: pg, tipo, tipo_interno: null, caso: d.caso || null, contexto_en: d.contexto_en || null, contexto_pt: null, enunciado_en: d.enun, enunciado_pt: null, enunciado_img: eimg, resposta_site: rs, resposta_site_img: rimg, resposta_correta: null, concordante: null, confianca: null, revisada_mesa: false, justificativa_pt: null, fontes: [] };
        if (nOpts > 0) q.opcoes = d.opcoes.map(o => ({ id: o.id, texto_en: o.texto_en, texto_pt: null, img: null })); else q.opcoes_img = eimg;
        // preservar verificação/traduções quando seq + numero coincidirem (a menos de --discard-verified)
        const old = oldBySeq[seq];
        if (old && !DISCARD && String(old.numero) === String(q.numero) && old.resposta_correta) { preserveVerified(q, old); stats.preservadas.push(seq); }
        else if (old) stats.substituidas.push(seq);
        else stats.adicionadas.push(seq);
        all.push(q);
      }
      console.log('Página', pg, '→', cards.length, 'questões (total', all.length + ')');
      // checkpoint após CADA página
      all.sort((a, b2) => a.seq - b2.seq);
      fs.writeFileSync(WORK + '/questions.json', JSON.stringify(all, null, 2));
      refreshProgress(progress, all);
      progress.paginas_com_erro = (progress.paginas_com_erro || []).filter(p => p !== pg);
      if (mode === 'page') {
        // recoleta pontual: NÃO mexe em ultima_pagina/proxima_pagina/status da coleta geral
      } else {
        progress.ultima_pagina = pg;
        progress.proxima_pagina = hasNext ? pg + 1 : null;
        if (!hasNext) { progress.status = 'concluido'; progress.fase = 'coleta_ok'; delete progress.mensagem; }
        else { progress.status = 'em_andamento'; progress.fase = 'coleta'; }
      }
      saveProgress(progress);
      if (mode === 'page') break;
      if (!hasNext) break; pg++;
    }
  } catch (e) {
    progress.status = 'erro'; progress.fase = 'coleta';
    if (mode !== 'page') { progress.ultima_pagina = pg; progress.proxima_pagina = pg; } // página que falhou é recoletada na retomada
    progress.paginas_com_erro = [...new Set([...(progress.paginas_com_erro || []), pg])];
    progress.mensagem = String(e.message || e).slice(0, 300);
    refreshProgress(progress, all);
    saveProgress(progress);
    console.error('ERRO na página', pg, '—', e.message, '| checkpoint salvo em progress.json (retome rodando o collect.js de novo)');
    try { await page.close(); await b.close(); } catch (_) {}
    process.exit(1);
  }
  all.sort((a, b2) => a.seq - b2.seq);
  fs.writeFileSync(WORK + '/questions.json', JSON.stringify(all, null, 2));
  const tipos = all.reduce((a, q) => { a[q.tipo] = (a[q.tipo] || 0) + 1; return a; }, {});
  console.log('OK:', all.length, 'questões em', WORK + '/questions.json', '| tipos:', JSON.stringify(tipos));
  console.log('Preservadas (verificação mantida):', stats.preservadas.join(',') || 'nenhuma');
  console.log('Substituídas:', stats.substituidas.join(',') || 'nenhuma', '| Adicionadas:', stats.adicionadas.length, 'questão(ões)');
  await page.close(); await b.close();
})().catch(e => { console.error('ERR', e.message); process.exit(1); });
