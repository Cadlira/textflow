# -*- coding: utf-8 -*-
# Gera os Word por tipo + estudos de caso. Uso: python gen-word.py <codigo> [baseDir]
# Requer: pip install python-docx
import json, os, sys
from docx import Document
from docx.shared import Cm

code = (sys.argv[1] if len(sys.argv) > 1 else '').lower()
if not code:
    print('uso: python gen-word.py <codigo> [baseDir]'); sys.exit(1)
BASE = sys.argv[2] if len(sys.argv) > 2 else r'C:\Workspace-Pessoal\Certificacoes'
OUT = os.path.join(BASE, code.upper())
qs = json.load(open(os.path.join(OUT, '_work', 'questions.json'), encoding='utf-8'))

def opt_en(q, letter):
    for o in (q.get('opcoes') or []):
        if o['id'] == letter: return o.get('texto_en', '')
    return ''

def resp_en(q):
    t = q['tipo']; c = q.get('resposta_correta') or {}
    if t == 'marcar_uma': l = c.get('letra', ''); return f"{l} — {opt_en(q, l)}"
    if t == 'multipla': ls = c.get('letras', []); return ", ".join(ls) + " — " + "; ".join(f"{l}: {opt_en(q, l)}" for l in ls)
    if t == 'sim_nao': return c.get('valor', '')
    if t == 'verdadeiro_falso':
        af = c.get('afirmacoes', {}); return "; ".join(f"Statement {i+1}: {'Yes' if af.get(a['id']) else 'No'}" for i, a in enumerate(q.get('afirmacoes', [])))
    if t in ('select', 'arrastar'):
        m = c.get('selecoes') or c.get('mapeamento') or {}
        rot = {a['id']: a.get('rotulo_en', a['id']) for a in q.get('alvos', [])}
        banco = q.get('banco_opcoes') or []; bid = {}
        for i, o in enumerate(banco):
            txt = o.get('texto_en', ''); bid[o.get('id') or ('o'+str(i+1))] = txt; bid.setdefault('o'+str(i+1), txt)
        def rez(v): return ", ".join(rez(x) for x in v) if isinstance(v, list) else bid.get(v, v)
        return " | ".join(f"{rot.get(k, k)} -> {rez(v)}" for k, v in m.items())
    if t == 'hotspot_imagem': return c.get('hotspot', '')
    return ''

def add_img(doc, rel):
    if not rel: return
    p = os.path.join(OUT, 'simulado', rel.replace('/', os.sep))
    if os.path.exists(p):
        try: doc.add_picture(p, width=Cm(15))
        except Exception: doc.add_paragraph(f'[imagem: {rel}]')

def add_q(doc, q):
    p = doc.add_paragraph(); r = p.add_run(f"Q{q['seq']}. "); r.bold = True
    p.add_run(q.get('enunciado_pt') or q.get('enunciado_en') or '')
    if q.get('enunciado_img'): add_img(doc, q['enunciado_img'])
    t = q['tipo']
    # Imagem fiel da área de resposta (opcoes_img) SEMPRE antes da transcrição textual,
    # em qualquer tipo visual (verdadeiro_falso, arrastar, select, hotspot_imagem, ...).
    # Não duplicar se for o mesmo arquivo do enunciado_img.
    # resposta_site_img NÃO entra nos Word limpos (só em auditoria/divergências).
    oimg = q.get('opcoes_img')
    if oimg and oimg != q.get('enunciado_img'):
        add_img(doc, oimg)
    if t in ('marcar_uma', 'multipla', 'sim_nao'):
        for o in (q.get('opcoes') or []): doc.add_paragraph(f"{o['id']}. {o.get('texto_pt') or o.get('texto_en','')}")
    elif t == 'verdadeiro_falso':
        for i, a in enumerate(q.get('afirmacoes', [])): doc.add_paragraph(f"{i+1}. {a.get('texto_pt') or a.get('texto_en','')}")
    elif t in ('select', 'arrastar'):
        for a in q.get('alvos', []): doc.add_paragraph(f"- {a.get('rotulo_pt') or a.get('rotulo_en','')}")
    pr = doc.add_paragraph(); rr = pr.add_run("Resp: "); rr.bold = True; pr.add_run(resp_en(q))
    doc.add_paragraph("")

groups = {'Questões.docx': ['marcar_uma', 'multipla'], 'Sim ou Não.docx': ['sim_nao'],
          'Verdadeiro ou Falso.docx': ['verdadeiro_falso'], 'Arrastar e Combobox.docx': ['arrastar', 'select', 'hotspot_imagem']}
created = []
for fname, types in groups.items():
    sel = [q for q in qs if q['tipo'] in types and not q.get('caso')]
    if not sel: continue
    doc = Document(); doc.add_heading(fname.replace('.docx', ''), level=1)
    for q in sel: add_q(doc, q)
    doc.save(os.path.join(OUT, fname)); created.append((fname, len(sel)))
casos = {}
for q in qs:
    if q.get('caso'): casos.setdefault(q['caso'], []).append(q)
for caso, items in casos.items():
    doc = Document(); doc.add_heading('Estudo de caso - ' + caso, level=1)
    ctx = items[0].get('contexto_pt') or items[0].get('contexto_en')
    if ctx: doc.add_paragraph(ctx); doc.add_paragraph('-' * 30)
    for q in items: add_q(doc, q)
    fn = f'Estudo de caso - {caso}.docx'; doc.save(os.path.join(OUT, fn)); created.append((fn, len(items)))
print('Word gerados:'); [print(' -', f, '(', n, ')') for f, n in created]
