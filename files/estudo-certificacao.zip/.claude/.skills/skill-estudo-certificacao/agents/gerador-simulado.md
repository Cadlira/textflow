---
name: gerador-simulado
role: builder
implements_code: true
description: >-
  Constrói o simulado interativo (sem servidor HTTP) a partir de questions.json: simulado.html +
  simulado-data.js + img/ + Chart.js local, seguindo a ordem exata do site, com correção por tipo,
  botão "Ver resposta" que só habilita quando a marcação está completa, motivo, divergência,
  estatísticas com gráficos e paginação 50/pág. Sub-agente.
---

# Gerador-simulado

## Objetivo
Gerar `<saída>\simulado\` conforme `references/simulado-spec.md`, pronto para abrir com **duplo
clique** (`file://`), sem servidor.

## Entradas
- `<saída>\_work\questions.json` (verificado) e imagens já em `<saída>\simulado\img\`.
- Referências: `simulado-spec.md` (UI/interação/stats/gráficos/localStorage), `esquema-dados.md`,
  `tipos-questao.md`.

## Forma recomendada (reprodutível)
Rode **`node tools/build-simulado.js <codigo>`** — ele já faz tudo: copia o **template único**
(`references/simulado-template.html`) + **Chart.js** (`tools/vendor/`) e gera o `simulado-data.js`
normalizado. Os passos abaixo descrevem o que esse tool garante (não recriar à mão).

## Procedimento
1. **`simulado.html`**: **copiar VERBATIM** o layout padrão `references/simulado-template.html`
   para `<saída>\simulado\simulado.html`. **Não reescrever do zero** — esse template é o padrão
   aprovado (controles por tipo, gating do "Ver resposta", filtro de agrupamento, cap da múltipla,
   PT/EN, estatísticas + gráficos). Só ajustar o template na própria skill se o padrão evoluir.
2. **`simulado-data.js`**: emitir `window.SIMULADO = { codigo, geradoEm, questoes:[...] }` com os
   campos do `questions.json` **normalizados** (na **ordem `seq`**). Caminhos de imagem **relativos**
   (`img/...`). Normalizar `select/arrastar` para o valor em **inglês** (a correção compara por texto EN)
   e marcar `autograde` por tipo (ver `simulado-spec.md`).
3. **`vendor/chart.umd.min.js`**: copiar o Chart.js de `node_modules` se existir; senão baixar uma
   vez o UMD minificado. **Nunca** referenciar CDN.
4. Copiar as imagens já capturadas para `<saída>\simulado\img\`.
5. Garantir robustez a campos ausentes e bom desempenho com 200+ questões (render só da página ativa).

## Saída
`<saída>\simulado\simulado.html`, `simulado-data.js`, `vendor/chart.umd.min.js`, `img/*` (já presentes).

## Regras
- **Sem servidor / sem CDN / offline**. Dados via `<script>` (não `fetch`). Imagens e Chart.js **locais**.
- Interface **toda em PT-BR**. Seguir `simulado-spec.md` fielmente (gating, correção, stats, gráficos).
- Não alterar `questions.json`; apenas consumir.
- Hotspot sem `bbox` confiável → fallback de botões rotulados; arrastar inviável → `<select>` por alvo.
