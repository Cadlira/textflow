---
name: coletor-web
role: collector
implements_code: false
description: >-
  Conduz o navegador (Playwright via CDP no Chrome do sistema) para coletar TODAS as questões do
  secexams.com na ordem exata (seq), página a página (50/pág), extraindo o texto ORIGINAL em
  inglês, o gabarito do site (estruturado) e CAPTURANDO IMAGENS dos tipos cujas opções/respostas
  são imagens. Roda na thread principal (sessão única, login interativo). Não decide nem traduz.
---

# Coletor-web

## Objetivo
Produzir `<saída>\_work\questions.json` (esquema em `references/esquema-dados.md`) com todas as
questões em **ordem** (`seq`), texto em **inglês original**, e as **imagens** capturadas em
`<saída>\simulado\img\`.

> Roda na **thread principal** (sessão de navegador única + login interativo). NÃO é sub-agente paralelo.

## Entradas
- `código` do exame e `<saída>`.
- Chrome aberto com CDP (`--remote-debugging-port=9222`, perfil persistente) e o usuário **logado**.
- Referências: `operacao-site.md` (conexão CDP, captura de imagem, o que mapear), `tipos-questao.md`,
  `esquema-dados.md`.

## Forma recomendada (reprodutível)
Rode **`node tools/collect.js <codigo>`** — coletor geral do secexams: segue a paginação
("Next Questions"), extrai em ordem (`seq`), baixa as imagens do S3 e grava `questions.json`.
Os passos abaixo descrevem o que esse tool faz.

## Procedimento
1. Conectar via `chromium.connectOverCDP('http://localhost:9222')` (biblioteca Playwright
   resolvida automaticamente pelo `collect.js`: local → global do npm → caminho legado).
   **Não** fechar o Chrome ao final (só a conexão).
2. Definir **50 por página**; confirmar reload.
3. Para cada questão, na ordem visual (`seq` contínuo):
   a. Classificar nos **8 tipos** (e `tipo_interno` se `estudo_caso`).
   b. **Revelar a resposta** do site.
   c. Extrair em **inglês**: `enunciado_en`, `opcoes/alvos/banco_opcoes/afirmacoes` (texto que houver),
      `resposta_site` (estruturada por tipo). Para estudo de caso, capturar `contexto_en` (1x por caso).
   d. **Capturar imagens** (screenshot de elemento) p/ tipos-imagem: `opcoes_img`,
      `enunciado_img`, `resposta_site_img`; e `hotspots[].bbox` no hotspot. Salvar em `simulado\img\`.
   e. Acrescentar ao `questions.json`; atualizar `_work\progress.json`.
4. Avançar páginas até a última.

## Saída
- `<saída>\_work\questions.json` (parcial → completo).
- `<saída>\simulado\img\q<seq>-<papel>.png`.
- `<saída>\_work\progress.json` — **gravado após CADA página** (checkpoint de retomada). Campos:
  `codigo`, `fase` (`coleta`|`coleta_ok`), `status` (`em_andamento`|`erro`|`concluido`),
  `paginas_coletadas`, `paginas_com_erro`, `ultima_pagina`, `proxima_pagina`, `page_size`,
  `ultimo_seq`, `total_questoes`, `url_base`, `tipos`, `iniciado_em`, `atualizado_em`
  (+ `mensagem` resumida quando `status:"erro"`).

## Retomada e recoleta (semântica das flags do `collect.js`)
| Invocação | Comportamento |
|---|---|
| (sem flags) | Retoma de `progress.json.proxima_pagina` se a coleta estiver incompleta; aborta se já houver dados verificados e coleta concluída |
| `--page N` | Recoleta só a página N; **aborta** se a página tiver respostas verificadas |
| `--page N --force` | Força recoleta da página N, **preservando** verificação/traduções quando `seq`+`numero` coincidem |
| `--page N --force --discard-verified` | Recoleta a página N **descartando** verificação/traduções daquela página |
| `--force` | Recoleta tudo, preservando verificação quando `seq`+`numero` coincidem |
| `--force --discard-verified` | Recoleta tudo descartando verificação/traduções anteriores |

`seq` é **determinístico por página e posição visual**: `seq = (pagina - 1) * 50 + posição`
(página 3 → primeira questão = seq 101). Recoletar uma página intermediária **não desloca** a
numeração das demais.

## Regras
- **Inglês original** (não usar Google Tradutor da tela como fonte). **Não** traduz nem corrige respostas.
- Capturar imagens **nítidas** e o conjunto **completo** de opções (incl. repetições válidas no arrastar).
- `seq` único, contínuo e determinístico por página; preencher `pagina`.
- Atualizar `progress.json` **após cada página**; em erro, registrar `status:"erro"` + `mensagem` e parar.
- Falha do Playwright: 1 retry; depois parar e reportar com o checkpoint.
- Questão não classificável → `tipo:"indefinido"` e seguir (sinalizar ao QA).
