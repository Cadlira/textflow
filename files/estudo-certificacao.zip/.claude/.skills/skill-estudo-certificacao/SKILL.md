---
name: skill-estudo-certificacao
description: >-
  DISPARE esta skill SOMENTE quando o usuário solicitar EXPLICITAMENTE estudar/gerar material de
  uma certificação a partir do simulador secexams.com (ex.: "estudar a certificação ab-730",
  "rodar a skill de certificação", "/skill-estudo-certificacao", "gerar os Word/o simulado do
  exame X"). Orquestra uma squad que: pergunta o código → abre o navegador (Playwright) e deixa o
  usuário logar → analisa o DOM → pagina 50/pág → lê cada questão em inglês e CAPTURA IMAGENS dos
  tipos com opções em imagem → estuda de forma independente (Microsoft Learn + web), transcreve e
  decide a resposta correta → compara com o gabarito do site → gera Word por tipo, um relatório .md
  só com divergências, e um SIMULADO interativo (sem servidor) com correção, motivo, divergência e
  estatísticas. NÃO dispare automaticamente para perguntas avulsas, navegação genérica ou dúvidas isoladas.
---

# Skill de Estudo de Certificações — Squad (secexams → Word + Simulado)

Transforma um simulado do **secexams.com** em material de estudo fiel: **documentos Word** por
tipo (pergunta em PT-BR, `Resp:` em inglês), um **`Divergências.md`** e um **simulado interativo**
(sem servidor) que segue a ordem exata do site, corrige o que você marca, mostra o **motivo**,
sinaliza **divergência** (site × verdade dos agentes) e acumula **estatísticas com gráficos**.

O orquestrador **coordena e conduz o navegador**, mas **não decide respostas sem estudo** nem gera
documentos/simulado sem verificação e auditoria.

> **✅ Validada em produção (AB-730, 2026-06-09):** um agente executou o fluxo completo
> (especialista → verificação ancorada no brief → mesa com the-fool) **só com base nesta skill**,
> verificando 86/86 questões; os investigadores eliminaram os falsos positivos do fluxo antigo
> (divergências caíram para 5). Evidências e convenção de artefatos em `references/revisao-e-failpoints.md`.

## Quando usar / quando NÃO usar
- **Use** só com pedido explícito (ver `description`).
- **Não use** para dúvida isolada, navegação genérica ou tarefas fora "gerar o material do simulado".
- **Reentrância:** se já houver `_work\questions.json`/`progress.json` do código, **retome do
  checkpoint** (`progress.json.proxima_pagina`/`paginas_coletadas`). A **coleta não recoleta nem
  sobrescreve** dados já verificados. Flags do `collect.js`: `--page N` recoleta só a página N
  (aborta se ela tiver verificação); `--force` recoleta **preservando** verificação/traduções
  quando `seq`+`numero` coincidem; `--force --discard-verified` descarta verificação/traduções.
  `seq` é determinístico: `(pagina-1)*50 + posição visual`.

## Fonte de dados única
Tudo gira em torno de `<saída>\_work\questions.json` (esquema em `references/esquema-dados.md`),
que alimenta os **Word** e o **simulado**. Imagens em `<saída>\simulado\img\`.

## Ferramentas reutilizáveis (`tools/`)
O pipeline está materializado em `tools/` (parametrizado pelo código do exame — ver `tools/README.md`):
`collect.js` (coleta+imagens+`progress.json`), `merge.js` (consolida verdicts com precedência
`mesa > consenso > produto > exame`), `compare-verdicts.js` (consenso entre os 2 verificadores),
`apply-traducoes.js` + `validate-ptbr.js` (gate de tradução), `gen-word.py` (gerador Word
**principal** — requer `python-docx`), `gen-divergencias.js`, `build-simulado.js` (copia o
**template único** + Chart.js e gera os dados). O **layout do simulado é o mesmo para qualquer
certificação** — `references/simulado-template.html` é copiado verbatim.

## Compatibilidade Claude Code / OpenCode

A skill funciona nos dois ambientes. **Instalação única e global** em
`~/.claude/skills/skill-estudo-certificacao/` (Windows:
`C:\Users\<usuario>\.claude\skills\skill-estudo-certificacao\`). **Não duplicar** a skill em
`~/.config/opencode/skills` — o OpenCode deve carregá-la a partir de `~/.claude/skills`.

**Comando de inicialização (idêntico nos dois ambientes):** `/estudo-certificacao [codigo]`
- Claude Code: `.claude/commands/estudo-certificacao.md` (no projeto) ou
  `~/.claude/commands/estudo-certificacao.md` (global).
- OpenCode: **global** em `~/.config/opencode/commands/estudo-certificacao.md`
  (não criar comando OpenCode local na pasta da skill).
- Após criar/alterar um comando, reinicie a sessão (Claude Code) ou o OpenCode para o comando
  ser reconhecido.

### Execução no OpenCode
- Os arquivos `agents/*.md` são **contratos de prompt/papel** — no OpenCode eles **não viram
  subagentes nomeados automaticamente**. O orquestrador deve ler cada arquivo e usar seu conteúdo
  como prompt ao invocar os subagentes disponíveis (ex.: `general`), preservando entradas/saídas
  e regras de cada papel.
- Preferir os **scripts reprodutíveis** para qualquer tarefa de arquivo: `collect.js`, `merge.js`,
  `compare-verdicts.js`, `apply-traducoes.js`, `validate-ptbr.js`, `gen-word.py`,
  `gen-divergencias.js`, `build-simulado.js`.
- Navegador: manter **Playwright via CDP** (`collect.js`) como caminho principal — independe de
  ferramentas específicas do Claude.
- Skills específicas do Claude citadas nesta skill têm fallback documentado (ex.: `the-fool` →
  `devils-advocate`); a geração de Word usa `gen-word.py` (sem dependência de skill docx).
- Os gates, fases e guardrails desta skill valem **igualmente** nos dois ambientes.

## Mapeamento de papéis
Agentes em `agents/`. O orquestrador **não programa** e **não gera docs/simulado**.

| Papel | Arquivo | Onde roda | Gera arquivos? |
|---|---|---|---|
| Orquestrador | (esta SKILL.md) | thread principal | não |
| Especialista da certificação | `agents/especialista-certificacao.md` | sub-agente (1x por exame) | `_work/especialista-brief.md` |
| Coletor-web | `agents/coletor-web.md` | thread principal (Playwright/CDP, sessão única) | `questions.json` + `img/` |
| Pesquisador-verificador | `agents/pesquisador-verificador.md` | sub-agentes **paralelos** (lotes disjuntos) | `_work/verdicts-exame-*.json` |
| Pesquisador-documentação-produto | `agents/pesquisador-documentacao-produto.md` | sub-agentes **paralelos** (só questões sem `muito_alta`) | `_work/verdicts-produto-*.json` |
| Mesa de decisão (+ the-fool/devils-advocate) | `agents/mesa-decisao.md` | sub-agente (só divergências/baixa confiança/conflito entre agentes) | `_work/verdicts-mesa.json` |
| Tradutor PT-BR | `agents/tradutor-ptbr.md` | sub-agentes **paralelos** (lotes disjuntos) | `_work/traducoes-*.json` |
| Redator-documentos | `agents/redator-documentos.md` | sub-agente (roda `python tools/gen-word.py <codigo>`) | os `.docx` |
| Gerador-simulado | `agents/gerador-simulado.md` | sub-agente (copia `references/simulado-template.html`) | `simulado\` |
| Auditor-QA | `agents/auditor-qa.md` | sub-agente | relatório de QA |

> Coleta **sequencial** (sessão única + login). Pesquisa **paralela** (sem navegador). O
> **brief do especialista** é a âncora de consistência; divergências passam pela **mesa de decisão**.

## Setup (Fase 0)
1. Perguntar o **código** (ex.: `ab-730`) → URL `https://www.secexams.com/exams/Microsoft/<código>/view/`.
2. Pasta de saída — default `C:\Workspace-Pessoal\Certificacoes\<CÓDIGO-MAIÚSCULO>\`.
3. Abrir o **Chrome do sistema** com CDP + perfil persistente (ver `references/operacao-site.md`):
   `--remote-debugging-port=9222 --user-data-dir=...\.playwright-profile <URL>`.
4. Pedir **login** ao usuário e aguardar confirmação (perfil persistente reaproveita depois).

## Fluxo por fases
1. **Fase 1 — Análise ao vivo:** após o login, conectar via CDP e mapear os **seletores reais** e
   como cada um dos **8 tipos** e suas **imagens** aparecem; fixar em `operacao-site.md`. Definir 50/pág.
2. **Fase 2 — Especialista (1x por exame):** `especialista-certificacao` estuda o guia oficial e
   gera `_work/especialista-brief.md` (objetivos, conceitos, armadilhas, links, heurísticas). É a
   **âncora de consistência**. Reusar se já existir.
3. **Fase 3 — Coleta:** `coletor-web` itera 50/pág em **ordem (`seq`)**, extrai **inglês original**
   e **captura imagens** dos tipos-imagem; grava `questions.json` + `progress.json` (checkpoint).
4. **Fase 4 — Verificação em dois estágios (paralela, ancorada no brief):**
   - **4a (exame):** lotes disjuntos; `pesquisador-verificador` transcreve imagens, decide
     `resposta_correta` estruturada, define `confianca` (5 níveis:
     `muito_baixa|baixa|media|alta|muito_alta`) e escreve `justificativa_pt`+`fontes` **para
     TODAS**; grava `_work/verdicts-exame-*.json`. **Viés a favor do site**: só marca
     `concordante:false` com **≥2 fontes oficiais**; senão mantém o site e rebaixa a `confianca`.
   - **4b (roteamento por questão):**
     | Resultado do 1º agente | Próximo passo |
     |---|---|
     | `muito_alta`/`alta` + `concordante:true` | aceitar como resposta final |
     | `muito_alta`/`alta` + `concordante:false` | `the-fool`/`devils-advocate` + mesa (Fase 5) |
     | `media`/`baixa`/`muito_baixa` | acionar `pesquisador-documentacao-produto` |
     | confiança ausente/inválida | acionar `pesquisador-documentacao-produto` + sinalizar no QA |
   - **4c (produto):** `pesquisador-documentacao-produto` em lotes disjuntos, **SEM receber**
     `resposta_site` nem a decisão do 1º agente (anti-ancoragem); pesquisa a documentação oficial
     do produto citado; grava `_work/verdicts-produto-*.json`.
   - **4d (consenso determinístico):** `node tools/compare-verdicts.js <codigo>` cruza os dois
     veredictos e o gabarito: gera `_work/analises-consenso.json` (auditoria interna — **nunca**
     vai para `questions.json`), `verdicts-consenso-*.json` (aceitos) e a **lista de mesa**.
     Consenso ≠ automático `muito_alta`: depende da força das fontes (2 fontes diretas →
     `muito_alta`; 1 → `alta`; nenhuma → `media`). **Consenso divergente do site NUNCA é aceito
     sem mesa.**
5. **Fase 5 — Mesa de decisão (the-fool):** para **toda** questão (i) `concordante:false` contra o
   site (qualquer confiança), (ii) com confiança final `baixa`/`muito_baixa`, ou (iii) em que os
   dois agentes **discordam** entre si: (a) o **orquestrador invoca a skill `the-fool` na THREAD
   PRINCIPAL** sobre a posição dos verificadores (a invocação de skill só é confiável aqui, não
   dentro de sub-agente). **Fallback:** se a skill `the-fool` não existir na máquina, usar a skill
   **`devils-advocate`** para gerar o contraditório (mesma regra: sempre na thread principal);
   (b) um sub-agente **`mesa-decisao` frio e independente** decide recebendo {questão, gabarito do
   site, posição dos DOIS verificadores+fontes, brief, crítica do the-fool}, confirmando divergência
   só com **≥2 fontes oficiais** — sendo ao menos uma `learn.microsoft.com` ou doc oficial de
   produto equivalente; `support.microsoft.com` só como segunda fonte (senão mantém o site;
   empate→site). Grava `_work/verdicts-mesa.json` (`revisada_mesa:true`), consolidado pelo
   `merge.js` (precedência `mesa > consenso > produto > exame`).
6. **Fase 6 — Tradução PT-BR (gate):** `tradutor-ptbr` em lotes disjuntos gera
   `_work/traducoes-*.json`; o orquestrador roda `node tools/apply-traducoes.js <codigo>` e o gate
   determinístico `node tools/validate-ptbr.js <codigo>`. **Word e simulado só podem ser gerados
   com o validador APROVADO** (nenhum `*_pt` exibido ao usuário ausente). Traduções nunca alteram
   respostas/veredictos. O fallback EN dos scripts é só proteção técnica, não entrega aprovada.
7. **Fase 7 — Word:** `redator-documentos` valida conteúdo/traduções e roda
   **`python tools/gen-word.py <codigo>`** (requer `python-docx`) para gerar os `.docx` por tipo +
   1 por estudo de caso (limpos, com `opcoes_img` nos tipos visuais).
8. **Fase 8 — Divergências:** `Divergências.md` (só `concordante:false`, já revisadas pela mesa).
9. **Fase 9 — Simulado:** `gerador-simulado` **copia `references/simulado-template.html`** e gera
   `simulado-data.js` + `img/` + `vendor/` (ver `simulado-spec.md`).
10. **Fase 10 — Auditoria/QA:** `auditor-qa` valida Word **e** simulado; corrigir a fase responsável e reauditar.

## Gates anti-pulo de fase (invioláveis)
1. Não iniciar a Verificação (Fase 4) sem o **brief do especialista** e o `questions.json` coletado.
2. Não iniciar Word/Simulado (Fases 7/9) sem `questions.json` **100% verificado**: `resposta_correta`,
   `concordante`, `confianca`, `justificativa_pt` em **todas**, imagens presentes nos tipos-imagem, e
   **toda** questão `concordante:false` ou `confianca ∈ {muito_baixa,baixa}` já **revisada pela mesa** (`revisada_mesa:true`).
3. Não iniciar Word/Simulado sem o **gate de tradução aprovado**: `node tools/validate-ptbr.js <codigo>`
   sem pendências (após `apply-traducoes.js`).
4. Não encerrar sem o **Auditor-QA** aprovar (Word + Simulado).
5. Cada gate exige **evidência** (arquivo + contagem), nunca inferência.

## Tratamento de falhas
- Ferramenta (Playwright/Task/docx): **1 retry**; se persistir, **pare e reporte** com o checkpoint
  (não invente resposta nem pule questão).
- Questão ilegível → `tipo:"indefinido"` e sinalizar no QA.
- Não fechar o Chrome do usuário (`b.close()` encerra só a conexão CDP).

## Guardrails (invioláveis)
1. Só o **Redator** gera `.docx` e só o **Gerador-simulado** gera o simulado.
2. Nunca decidir resposta sem estudo; o gabarito do site é **hipótese**, mas com **viés a favor
   dele**: só contrariar com **≥2 fontes oficiais**. **Consistência:** ancorar tudo no brief do
   especialista; divergências/baixa confiança **sempre** passam pela mesa de decisão (com `the-fool`;
   fallback `devils-advocate` se `the-fool` não existir).
3. **Pergunta/opções em PT-BR**; `Resp:` dos Word em **inglês**; simulado bilíngue (PT padrão, toggle EN).
4. Tradução **limpa pela IA** (não copiar Google Tradutor); extração lê o **inglês original**.
   A tradução é do **`tradutor-ptbr`** (`_work/traducoes-*.json` → `apply-traducoes.js`), com gate
   `validate-ptbr.js` antes de Word/simulado; scripts **não** fazem tradução automática.
5. Tipos com opções/respostas em imagem: **capturar a imagem fiel E transcrever** para texto.
6. **`justificativa_pt` em todas** (motivo do simulado). Word seguem **limpos** (justificativa só no `Divergências.md`).
7. Simulado **sem servidor/sem CDN/offline**; dados via `<script>`; imagens e Chart.js **locais**.
   **Template único e imutável:** copiar `references/simulado-template.html` **verbatim** para todo
   exame (idêntico para qualquer certificação); só varia `simulado-data.js`. Nunca recriar o HTML por exame.
8. Login é do usuário (interativo); respeitar perfil persistente. Não burlar login.
9. Pesquisa paralela só com **lotes disjuntos**; coleta sempre **sequencial**.
10. Não pular gates; transições exigem evidência em `_work/`. Em divergência, **2 fontes oficiais**.

## Auditoria final (checklist)
| Item | Evidência |
|---|---|
| Todas as páginas (50/pág) e `seq` contínuo | `progress.json` + contagem |
| 100% verificado (resposta+motivo+imagens) | `questions.json` |
| Word por categoria + 1 por caso; PT/`Resp:` EN; limpos; `opcoes_img` nos tipos visuais | abrir amostras dos `.docx` |
| `Divergências.md` consistente | conferido pelo QA |
| Simulado abre em `file://`, corrige por tipo, motivo, divergência, paginação configurável (default 50), stats+gráficos | abrir `simulado.html` |
| QA sem pendências | relatório do Auditor-QA |
