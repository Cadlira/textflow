# Revisão, pontos de falha e contrato da Mesa/the-fool

Conhecimento consolidado da revisão geral (mantido na skill). Reler antes de rodar a verificação.

## Contrato de execução da Mesa de Decisão + the-fool (CRÍTICO)
A invocação de skill (`the-fool`) **só é confiável na thread principal** — não dentro de sub-agente.
Por isso a mesa é **orquestrada**, não um sub-agente que "chama o the-fool":

1. **Thread principal (orquestrador):** para cada questão `concordante:false` **ou** `confianca:"baixa"`,
   invoca a skill **`the-fool`** sobre a posição do verificador (resposta + fontes + enunciado +
   gabarito do site + trechos do brief). **Fallback:** se `the-fool` não existir na máquina, o
   contraditório é gerado com a skill **`devils-advocate`** (também na thread principal — nunca
   dentro do sub-agente da mesa). Guarda a **crítica** (pré-mortem, furos, leitura alternativa,
   pegadinha de licença/escopo).
2. **Sub-agente `mesa-decisao` (frio, independente):** decide do zero com
   {questão, gabarito do site, posição do verificador+fontes, brief, crítica do the-fool}.
   - Confirma divergência **só com ≥2 fontes oficiais** do Microsoft Learn; senão **mantém o site**.
   - **Empate/dúvida → mantém o site** (regra de desempate).
3. Saída em `_work/verdicts-mesa.json` (keyed por seq, `revisada_mesa:true`); `merge.js` consolida.

> O contraditório precisa ser **real**: quem decide (mesa) **não é** quem propôs (verificador), e o
> the-fool roda **fora** do decisor.

## Estabilidade entre execuções (por que as respostas variavam)
Causas: agentes "frios" paralelos sem âncora + nondeterminismo do modelo + flag de divergência com
evidência fraca. Estabilizadores (todos obrigatórios):
- **Brief do especialista** = âncora única de conhecimento (mesma base → mesma resposta).
- **Viés a favor do site** + **≥2 fontes oficiais** para divergir.
- **Mesa com the-fool independente** nos casos sensíveis.
- **Desempate = manter o site.**
> Determinismo é aspiracional (LLM varia); estas regras tornam **as divergências** estáveis e raras/justificadas.

## Pontos de falha conhecidos e mitigação
| Ponto | Risco | Mitigação |
|---|---|---|
| Coleta sobrescreve `questions.json` | perder verificação | `collect.js` aborta se houver verificado; `--page`/`--force` conscientes |
| Imagem S3 não-pública (403/CORS) | imagem faltando | fallback `fetch` no contexto da página; por último, screenshot do elemento |
| `data-correct`/seletores do secexams mudam | coleta quebra | revalidar seletores em `operacao-site.md` (análise ao vivo) |
| Transcrição de imagem imprecisa (V/F, select, hotspot) | resposta/al­ternativa errada | verificador confere contra o Learn; baixa confiança → mesa |
| `hotspot_imagem`/`arrastar` sem dados estruturados | sem auto-correção | `autograde:false` → auto-avaliação no simulado (fallback aceitável) |
| Sub-agentes batendo limite de sessão | lote incompleto | lotes menores; retomar; merge tolera lotes parciais |
| `justificativa_pt` narrando o processo ("the-fool exigiu…", "a mesa…", "o site marcou…") | motivo inútil para estudar | motivo **didático** (conceito; por que certa/erradas; por item em V/F); deliberação só em `the-fool-critique.md`; auditor reprova narração |
| Confiança "baixa" por pesquisa rasa (ex.: seq 79 — limite de 15 execuções era encontrável) | resposta certa subvalorizada / dúvida não resolvida | esgotar Learn/Support + busca direcionada a detalhes numéricos antes de aceitar "baixa"; calibração de confiança definida |
| Motivo ausente no "Ver resposta" | aluno sem explicação | template **sempre** renderiza "Motivo:"; gate/auditor exigem `justificativa_pt` em todas |

## Estado de validação dos investigadores — ✅ COMPROVADO (AB-730, 2026-06-09)
A cadeia **especialista → verificação ancorada no brief → mesa com the-fool** foi **executada de
ponta a ponta por um agente, inteiramente com base nesta skill**, no exame AB-730 (86 questões).
Evidências (em `<saída>\_work\`): `especialista-brief.md`, lotes `verdicts-001-018.json …
verdicts-071-086.json`, `the-fool-critique.md`, `verdicts-mesa.json` → `questions.json` com
**86/86 verificadas**, 20 revisadas pela mesa.

**Prova de que os investigadores funcionam:** sob o fluxo novo (viés a favor do site + ≥2 fontes +
mesa com the-fool), as divergências ficaram em **5 (seq 51, 53, 74, 82, 86)** e os **falsos
positivos do fluxo antigo (seq 17/18) reverteram para concordante** — exatamente o comportamento
esperado. Confiança resultante: Alta 55 / Média 20 / Baixa 11. **A skill está validada em produção.**

## Convenção de artefatos da verificação (ATUALIZADA — seguir)
- **Brief:** `_work/especialista-brief.md` (1× por exame, âncora).
- **Lotes do 1º agente (exame):** `_work/verdicts-exame-<inicio>-<fim>.json` com **zero-padding**
  e lotes de ~**18 questões** (ex.: `verdicts-exame-001-018.json`). Keyed por `seq`.
- **Lotes do 2º agente (produto):** `_work/verdicts-produto-<inicio>-<fim>.json` (só questões
  roteadas — 1º veredito sem `muito_alta`+`concordante:true`).
- **Consenso:** `tools/compare-verdicts.js` → `_work/analises-consenso.json` (auditoria interna)
  + `_work/verdicts-consenso-<inicio>-<fim>.json` (aceitos) + lista de mesa.
- **Contraditório:** `_work/the-fool-critique.md` (crítica do the-fool — ou do `devils-advocate`
  como fallback — sempre da thread principal).
- **Mesa:** `_work/verdicts-mesa.json` (questões revistas, `revisada_mesa:true`).
- **Consolidação:** `merge.js` aplica com precedência `mesa > consenso > produto > exame > legado`
  (`verdicts-mesa.json` sempre por último; `revisada_mesa:true` nunca é sobrescrito).
- **Legado:** o formato antigo `verdicts-<inicio>-<fim>.json` não deve ser criado para novas
  verificações; se existir de execuções anteriores, o `merge.js` o trata como veredito de exame
  com a **menor** precedência.
