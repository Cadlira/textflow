# Referência — Operação do site secexams.com (Playwright)

Como o **Coletor-web** opera o navegador para coletar questões **e capturar imagens**. Roda na
**thread principal** (sessão única, login interativo).

> **Seletores concretos:** confirmados na análise ao vivo do **ab-730** (ver seção
> "Seletores confirmados"). Revalidar se o secexams mudar o layout.

## Seletores confirmados (secexams, análise ao vivo ab-730)

- **Card de questão (ativo):** `div[id^="nav-question"]` (ex.: `nav-question602878`). Ignorar as
  abas irmãs `nav-discussion*`, `nav-settings*`, `nav-tabContent` (não são questões).
- **Número:** `h5` dentro do card → texto `"Question #N"`.
- **Enunciado:** `.question-description` (usar innerText; trocar `<br>`→quebra de linha).
  - **Imagem do enunciado/exhibit:** `.question-description img:not([src*="gpt.png"])` →
    baixar `src` (S3 `/media/questions/<hash>.png`).
- **Opções (tipos de texto):** `ol.rounded-list > li` → `.option-circle` (letra) + `.option-text`
  (texto). Correção **já no DOM**: `li[data-correct="True"]`.
- **Gabarito do site:** `#answerQ<id> .correct-answer` →
  - texto com as letras (ex.: `"CD"`) para MCQ; **ou**
  - `.correct-answer img` (S3) para tipos de imagem (HOTSPOT/arrastar/select/V-F) → baixar `src`.
  - (O bloco `#answerQ*` é `.collapse`; **não precisa clicar** "Show Answer" — o conteúdo já está no DOM.)
- **Tipos de imagem:** detectados por `ol.rounded-list` **vazio** (`nOpts==0`) **+** imagem no
  enunciado **+** `.correct-answer img`. Subclassificar pelo texto do enunciado:
  `"DRAG AND DROP"`→`arrastar`; `"select Yes if the statement is true"`→`verdadeiro_falso`;
  `"Select the answer that correctly completes the sentence"`→`select`; demais `"HOTSPOT"` com
  figura/áreas→`hotspot_imagem`. (Em todos, capturar imagem do enunciado + imagem da resposta.)
- **MCQ single vs múltipla:** nº de letras corretas (1→`marcar_uma`; ≥2→`multipla`). "Which two/
  Each correct answer presents part…" confirma `multipla`.
- **`sim_nao`:** opções de texto literais Yes/No com "Does this meet the goal?" (não há no ab-730 p.1;
  comum em outros exames).
- **Paginação:** URL `https://www.secexams.com/exams/Microsoft/<código>/view/<n>` (n=1,2,…). Seguir
  o link **"Next Questions"** (`a[href*="/view/"]` com esse texto) até ele **não existir**. Já vem
  **50/página**. Não confiar em `/view/<n>` fora do range (o site repete a última página).

## Conexão ao navegador (abordagem atual: Chrome do sistema + CDP)

A biblioteca **Playwright** é resolvida automaticamente pelo `collect.js` (local → global do npm →
caminho legado; `PLAYWRIGHT_PATH` é override opcional). Basta `npm i -g playwright` — **sem**
baixar navegadores, pois a conexão é via CDP no Chrome do sistema. O Chrome é aberto com porta de
depuração e **perfil persistente**:

```powershell
& "C:\Program Files\Google\Chrome\Application\chrome.exe" `
  --remote-debugging-port=9222 `
  --user-data-dir="C:\Workspace-Pessoal\Certificacoes\.playwright-profile" `
  "https://www.secexams.com/exams/Microsoft/<código>/view/"
```

O usuário **loga** (perfil persistente reaproveita o login depois). Scripts Node conectam ao
Chrome existente (não fecham o navegador):

```js
// o collect.js resolve o playwright sozinho; em scripts avulsos use require('playwright')
// (instalação local/global) — caminho absoluto só se necessário:
const { chromium } = require('playwright');
const b = await chromium.connectOverCDP('http://localhost:9222');
const ctx = b.contexts()[0];
const page = ctx.pages().find(p => p.url().includes('secexams')) || ctx.pages()[0];
// ... ler/extrair/screenshot ...
await b.close(); // fecha só a conexão CDP, NÃO o Chrome
```

> Alternativa "designed": **Playwright MCP** (`.mcp.json` em Certificacoes) com ferramentas
> `mcp__playwright__browser_*`. Só funciona se a sessão do Claude estiver enraizada em
> Certificacoes e o MCP conectado. A abordagem CDP acima funciona em qualquer sessão.

## O que mapear na análise ao vivo (Fase 1)

- container de cada **questão** e como vem o **número/seq**;
- **enunciado** (texto) e **imagem** do enunciado (hotspot);
- **opções** por tipo: radios, checkboxes, **selects**, banco de **arrastar** + caixas-alvo,
  grade **V/F**, **imagem** das opções;
- botão/área de **revelar resposta** ("Reveal Solution"/"Answer") e onde aparece o gabarito
  (texto ou **imagem**);
- seletor de **itens por página** (definir **50**) e botão de **próxima página**;
- indicador de **estudo de caso** (menu lateral de contexto) e como o contexto é exibido.

## Procedimento de coleta (em ordem `seq`)

1. Conectar via CDP; achar a página do exame.
2. Definir **50 por página** (selecionar no controle ou via parâmetro de URL) e confirmar reload.
3. Para cada página, na ordem visual:
   a. Identificar o `tipo` (ver `tipos-questao.md`).
   b. **Revelar a resposta** da questão.
   c. Extrair, em **inglês original**: `enunciado_en`, `opcoes/alvos/banco_opcoes/afirmacoes`
      (texto), `resposta_site` (estruturada). Atribuir `seq` contínuo e `pagina`.
   d. **Capturar imagens** quando o tipo for de imagem (ver abaixo) → salvar em
      `<saída>\simulado\img\` com nome `q<seq>-<papel>.png`.
   e. Acumular no `questions.json` e atualizar `_work\progress.json`.
4. Avançar para a próxima página; repetir até a última.

## Captura de imagens (Playwright)

**No secexams, prefira BAIXAR a imagem pelo `src` do S3** (`/media/questions/<hash>.png`) — é o
arquivo original, exato, sem rendering. Baixe via `fetch` same-origin no contexto da página
(carrega com os cookies de login) ou `https.get`, e salve em `<saída>\simulado\img\`:

```js
const url = await el.getAttribute('src');                 // .question-description img / .correct-answer img
const buf = Buffer.from(await page.evaluate(async u => {
  const r = await fetch(u, { credentials: 'include' }); const b = await r.arrayBuffer();
  return Array.from(new Uint8Array(b));
}, url));
require('fs').writeFileSync('C:/.../simulado/img/q12-enunciado.png', buf);
```

Só faça **screenshot de elemento** (fallback) se a resposta/figura não for uma `<img>` baixável:

```js
const el = page.locator('<seletor-do-elemento>');           // confirmado na análise ao vivo
await el.screenshot({ path: 'C:/.../simulado/img/q10-opcoes.png' });
const box = await el.boundingBox();                          // p/ hotspots: bbox relativo à imagem
```

- `arrastar`/`select`: screenshot do bloco de opções/alvos → `opcoes_img`.
- `verdadeiro_falso`: screenshot da grade de afirmações/respostas → `opcoes_img`.
- `hotspot_imagem`: screenshot da figura → `enunciado_img`; para cada área clicável, registrar
  `bbox` (coordenadas **relativas à imagem capturada**) em `hotspots[]`.
- gabarito revelado em imagem → `resposta_site_img`.
- Caminhos gravados no JSON são **relativos** (`img/q10-opcoes.png`).

## Nota de idioma

- **Extraia sempre o inglês original** (melhor para a `resposta` em inglês e para a tradução PT
  limpa feita depois pelo Redator). Não use o Google Tradutor da tela como fonte.
- A transcrição das **imagens → texto** é feita pelo **Pesquisador-verificador** (ele lê a imagem
  capturada e preenche os `*_en`); o Coletor garante a **imagem nítida** e o que conseguir de texto.

## Saída
- `<saída>\_work\questions.json` (esquema em `esquema-dados.md`).
- `<saída>\simulado\img\*.png` (imagens capturadas).
- `<saída>\_work\progress.json` — checkpoint gravado **após cada página** (`status`, `fase`,
  `paginas_coletadas`, `paginas_com_erro`, `proxima_pagina`, `page_size`, `url_base`, `tipos`,
  `ultimo_seq`, `total_questoes`, timestamps). É a evidência de retomada/completude da coleta:
  sem flags, o `collect.js` retoma de `proxima_pagina` sem recoletar páginas concluídas.

## Regras
- Coleta **sequencial** (sessão única). Em falha do Playwright: 1 retry; depois pare e reporte com o checkpoint.
- Não feche o Chrome do usuário (`b.close()` encerra só a conexão CDP).
- Revele e capture o conjunto **completo** de opções (inclusive repetições válidas no arrastar).
