# Referência — Especificação do Simulado interativo

Define o que o **gerador-simulado** deve construir. Objetivo: app de estudo **simples, sem
servidor HTTP**, que abre com **duplo clique** (`file://`), segue a **ordem exata** do site,
deixa responder, mostra a resposta correta + **motivo**, sinaliza **divergência** e acumula
**estatísticas com gráficos**.

## Layout padrão (canônico) — ÚNICO e IMUTÁVEL por certificação

⚠️ **REGRA INVIOLÁVEL:** existe **um único** template de simulado —
**`references/simulado-template.html`** — e ele é **idêntico para QUALQUER certificação**. O
`gerador-simulado` **copia esse arquivo VERBATIM** (byte a byte) para `<saída>\simulado\simulado.html`
e **só varia o `simulado-data.js`** (+ `img/` + `vendor/`). 

- **NUNCA** reescrever, recriar ou "adaptar" o HTML por exame. O template é exam-agnóstico: o
  código do exame, as questões e tudo mais vêm de `window.SIMULADO` (ver contrato abaixo).
- Melhorias de layout/comportamento são feitas **uma vez**, editando este template na skill —
  e passam a valer para todos os exames na próxima geração.
- O template não contém nenhuma string específica de exame (validado: 0 ocorrências de código de exame).

## Contrato de dados do template (`window.SIMULADO`)

O template consome **exatamente** esta forma (o `gerador-simulado`/`tools/build-simulado.js`
normaliza o `questions.json` para cá). Mantê-la estável garante que o mesmo template sirva a todos:

```jsonc
window.SIMULADO = {
  codigo: "AB-730", geradoEm: "<ISO>",
  questoes: [ {
    seq, numero, tipo,                         // tipo = um dos 8
    caso: null | "Fabrikam",
    contexto: null | { pt, en },
    enunciado: { pt, en },
    enunciadoImg: null | "img/..", opcoesImg: null | "img/..", respSiteImg: null | "img/..",
    opcoes:     [ { id, pt, en } ],            // marcar_uma | multipla | sim_nao
    afirmacoes: [ { id, pt, en } ],            // verdadeiro_falso
    alvos:      [ { id, pt, en } ],            // select | arrastar
    banco:      [ { id, pt, en } ],            // select | arrastar (o <option> usa `en` como value)
    hotspots:   [ { id, pt, en } ],            // hotspot_imagem
    correta: {…}, site: {…},                   // estruturadas por tipo (ver esquema-dados.md)
    concordante: bool, confianca: "muito_baixa|baixa|media|alta|muito_alta", motivo: "pt", fontes: ["url"],
    autograde: bool                            // false => fallback (mostra imagem + auto-avaliação)
  } ]
}
```
**Regra do `autograde`** (corrige automaticamente) por tipo: `marcar_uma` (tem `opcoes` + `correta.letra`);
`multipla` (`correta.letras`); `sim_nao` (`correta.valor`); `verdadeiro_falso` (`afirmacoes` + `correta.afirmacoes`);
`select` (`alvos`+`banco`+`correta.selecoes`); `arrastar` (`+correta.mapeamento`); `hotspot_imagem`
(`hotspots`+`correta.hotspot`). Sem os dados estruturados → `autograde:false` (auto-avaliação).

## Estrutura de arquivos (em `<saída>\simulado\`)

```
simulado/
├── simulado.html            # UI + lógica (HTML/CSS/JS puro, sem build)
├── simulado-data.js         # window.SIMULADO = { codigo, geradoEm, questoes:[...] }
├── img/                     # imagens capturadas (enunciado/opções/gabarito)
└── vendor/
    └── chart.umd.min.js     # Chart.js vendorizado LOCAL (sem CDN)
```

**Por que `simulado-data.js` e não `.json`:** em `file://` o `fetch()` é bloqueado. Os dados
entram como variável global via `<script src="simulado-data.js">`. As imagens são carregadas por
`<img src="img/...">` (caminho relativo funciona em `file://`). Gráficos via `<script
src="vendor/chart.umd.min.js">` local.

> Obter o Chart.js local: copiar de `node_modules` se existir, senão baixar uma vez o UMD
> minificado para `vendor/`. Nunca referenciar CDN (precisa funcionar offline).

## Layout da página

- **Cabeçalho fixo:** código do exame • progresso "respondidas X/N" • **filtro por tipo** •
  **"Por página"** (presets 10/25/50/100 + campo personalizado; **default 50**, persistido em
  `localStorage:simulado_pagesize_<codigo>`, clamp [1, total]) • **toggle "Embaralhar opções"**
  (ver regra abaixo) • botão **PT / EN** • botões **Finalizar simulado**, **Estatísticas**, **Reiniciar**.

### Toggle "Embaralhar opções" (regra fixa)
- **Padrão: LIGADO.** Persistido em `localStorage:simulado_shuffle_<codigo>`.
- Quando ligado, embaralha **apenas a apresentação** de: `marcar_uma` e `multipla` (alternativas)
  e `arrastar` (banco de opções). **Não embaralha**: `select` (a ordem pode representar o campo da
  questão), `verdadeiro_falso` (a ordem das afirmações é parte da leitura), `sim_nao` (sem ganho) e
  `hotspot_imagem` (interação visual).
- O embaralhamento é **estável por tentativa+questão** (seed determinística com o id da tentativa):
  não muda ao trocar página, idioma ou abrir estatísticas; muda a cada nova tentativa.
- Para `marcar_uma`/`multipla`, as **letras visuais** (A, B, C, …) são recalculadas pela posição
  exibida; **a correção e as estatísticas usam SEMPRE os IDs originais das opções capturadas** —
  letras visuais são apenas apresentação. O embaralhamento **não altera** `questions.json` nem
  `simulado-data.js` (é comportamento de UI).
- **Corpo:** um **card por questão** da página atual (50). Cada card:
  - cabeçalho do card: `#seq` • tipo • (selo "Estudo de caso: <Nome>" quando aplicável).
  - para `estudo_caso`: bloco de **contexto** (colapsável) acima das questões do caso.
  - **enunciado** (PT por padrão; EN no toggle) + `enunciado_img` quando houver.
  - **controle interativo** conforme o tipo (abaixo). Em tipos-imagem, exibir a **imagem fiel**
    (`opcoes_img`) ao lado do controle, como referência visual da prova.
  - botão **"Ver resposta"** (desabilitado até a marcação obrigatória estar completa).
  - **painel de resultado** (oculto até "Ver resposta").
- **Rodapé/nav:** Anterior/Próxima questão; navegação entre páginas de 50.
- **Selos no canto superior direito de cada card** (sempre visíveis):
  - **Confiança (5 níveis):** "Confiança: Muito Baixa / Baixa / Média / Alta / Muito Alta"
    (cores: vermelho-escuro → vermelho → âmbar → verde → verde-escuro), a partir de `confianca`
    (`muito_baixa|baixa|media|alta|muito_alta`); `n/d` se ausente.
  - **Divergência:** "⚠ Divergência" (âmbar) quando `concordante:false`, ou "✓ Sem divergência" (verde) quando `concordante:true`.
  - **Padrão: sempre visível** (inclusive antes de responder).
  - **Trade-off (spoiler):** como o selo indica que o gabarito do site difere do nosso, ele é uma
    leve dica antes de responder. **Decisão atual: manter sempre visível** (o usuário priorizou
    saber de cara quais questões são "polêmicas").
  - **Alternativa configurável:** exibir o selo **somente após "Ver resposta"** — basta, no template,
    inserir o selo no painel de resultado (em vez do cabeçalho do card). Trocar entre os dois modos
    é uma mudança localizada em `simulado-template.html`.

## Controles e regra de habilitação ("Ver resposta")

O botão **só habilita** quando a marcação obrigatória do tipo está completa:

| `tipo` | Controle | Habilita quando |
|---|---|---|
| `marcar_uma` | radios (opções PT/EN) | 1 selecionado |
| `multipla` | checkboxes | nº de marcados = nº de corretas; **bloqueia** marcar além disso e exibe "Selecione N opção(ões)" |
| `sim_nao` | 2 botões (Sim/Não) | 1 escolhido |
| `verdadeiro_falso` | toggle V/F por afirmação | **todas** respondidas |
| `select` | um `<select>` por alvo (options = `banco_opcoes` transcritas) | **todos** escolhidos |
| `arrastar` | **drag-and-drop**: banco de ações (chips arrastáveis e **reutilizáveis**) + uma **área de soltura por alvo que aceita VÁRIOS itens** (a mesma ação pode ir para mais de um alvo e repetir). Arrastar ou clicar (seleciona chip → clica na área); cada item colocado tem **× p/ remover**. Fallback de clique p/ toque | **cada alvo com ≥1 item** |
| `hotspot_imagem` | **overlay clicável** sobre `enunciado_img` quando houver `bbox` relativo; senão botões rotulados | 1 área/botão escolhido |
| `estudo_caso` | usa o controle do `tipo` real da questão (`caso` é só agrupador) | regra do tipo |

**Arrastar (detalhes):** a **mesma opção pode ir para mais de um alvo** e um alvo pode receber
**vários itens** (`mapeamento` com lista). A correção compara **multiconjunto por alvo** (ordem
não importa; repetição importa). O controle é **drag-and-drop**: um banco de ações (chips
arrastáveis, **reutilizáveis** — não se esgotam) e, por alvo, **uma área de soltura que aceita
vários itens** (sem nº fixo de slots — não vaza a quantidade certa). A mesma ação pode ir para
mais de um alvo e repetir no mesmo alvo; cada item colocado tem **× para remover**. Suporta
arrastar (HTML5 DnD) **e** clicar (selecionar chip → clicar na área). O estado salvo é
`st.marcado[alvo] = [valores en]` (multiconjunto dinâmico), preservando `isComplete` (cada alvo
com ≥1 item) e `grade` (multiconjunto por alvo). Ao revelar, os itens colocados ficam **verdes/
vermelhos** conforme a multiplicidade correta. A imagem original do enunciado fica em **collapse**
(`<details>`) para não ocupar espaço.

**Hotspot (regra de fallback):** `bbox` é **opcional**. Se `hotspots[].bbox` existir no formato
**relativo** (`{x,y,w,h,unit:"relative"}`, 0..1), o template renderiza **áreas clicáveis sobre a
imagem** (escalam com o redimensionamento). Sem `bbox` (ou com bbox legado em pixels, descartado
pelo build), mostra a imagem + **botões rotulados** (`hotspots[].rotulo_pt`). A ausência de
`bbox` **não bloqueia** a geração; o QA valida que o tipo funciona em pelo menos um dos modos.

## Agrupamento / Filtro de estudo

Seletor no cabeçalho (`#grpFilter`) para **estudar só um tipo**. Opções:
- **Todas as questões**
- **Marcar uma ou mais** (`marcar_uma` + `multipla`, **sem** questões de caso)
- **Verdadeiro ou Falso** (`verdadeiro_falso`, sem caso)
- **Sim ou Não** (`sim_nao`, sem caso)
- **Arrastar / Select / Hotspot** (`arrastar` + `select` + `hotspot_imagem`, sem caso)
- **Estudos de caso** (`caso != null`) — **agrupados por caso** (cabeçalho por estudo de caso),
  questões em ordem `seq`, com o **contexto exibido UMA vez por caso** em bloco **colapsável** no
  topo da seção. Questões de caso **não duplicam** nas categorias comuns (aparecem em "Todas" e
  em "Estudos de caso").

Ao trocar o filtro: volta para a página 1, pagina conforme **"Por página"** sobre o subconjunto, e mostra
"Nenhuma questão neste grupo" se vazio. As estatísticas continuam considerando todas as respondidas.

## Correção (ao clicar "Ver resposta")

Comparar a marcação do usuário com `resposta_correta` (estrutura por tipo — ver `esquema-dados.md`):
- `marcar_uma`/`sim_nao`: igualdade simples.
- `multipla`: igualdade de conjunto de letras.
- `verdadeiro_falso`: todas as afirmações corretas (mostrar acerto por afirmação).
- `select`: todos os alvos corretos.
- `arrastar`: multiconjunto por alvo igual (ordem não importa; repetição importa).
- `hotspot_imagem`: área escolhida == `hotspot`.

**Painel de resultado ("Ver resposta")** exibe a resposta **COMPLETA**, nunca só a letra:
1. **Correto ✅ / Incorreto ❌** (e, em V/F/select/arrastar, o detalhe por item).
2. **Resposta correta** completa, no idioma atual, por tipo:
   - `marcar_uma`: **letra visual atual + texto completo** da opção;
   - `multipla`: **letras visuais atuais + textos completos** das opções corretas;
   - `sim_nao`: **`Yes`/`No`** e, se houver, a opção visual correspondente;
   - `verdadeiro_falso`: **cada afirmação** com seu `Yes`/`No`;
   - `select`/`arrastar`: **cada alvo → opção(ões) correta(s)** (listas exibidas por completo);
   - `hotspot_imagem`: **rótulo/descrição** do hotspot correto.
   Com embaralhamento ligado, a letra visual exibida é a **da tentativa atual**, preservando o ID
   original usado na correção.
3. **Motivo (SEMPRE exibido):** `justificativa_pt` (didático — explica por que a correta/erradas;
   nunca narra o processo) + lista de **Fontes** (`fontes[]`, links clicáveis). O template **sempre**
   renderiza a linha "Motivo:" (se faltar, mostra "(motivo não informado — revisar)" para flagrar —
   e o Auditor-QA **reprova** a entrega final com motivo ausente).
4. Se `concordante == false`: **selo "Divergência"** com duas linhas — "Gabarito do site: …" ×
   "Resposta dos agentes: …" — com **texto completo** sempre que possível.
5. Marca a questão como respondida e registra acerto/erro na tentativa atual (persistida).
6. Questões `autograde:false` mostram os botões **Acertei/Errei** — a questão **só entra nas
   estatísticas** depois que o usuário marcar um deles (disponível também após reload).

> Após "Ver resposta", os controles ficam **somente leitura** (não reabre para mudar a marcação
> na mesma tentativa).

## Idioma (PT/EN)

Botão global alterna **enunciado + opções/alvos/afirmações** entre `*_pt` (padrão) e `*_en`
(inglês original do site). `justificativa_pt` permanece em PT. As imagens são as mesmas (são do
site, em inglês).

> **Gate de tradução:** antes de gerar o simulado, `node tools/validate-ptbr.js <codigo>` deve
> estar aprovado — todo campo exibido ao usuário precisa do `*_pt` (o fallback `pt: texto_en` do
> `build-simulado.js` é proteção técnica, não entrega aprovada).

## Estatísticas (localStorage) — contrato VERSÃO 2

Chave: `simulado_stats_<codigo>`. Estrutura obrigatória:
```jsonc
{
  "versao": 2,
  "tentativaAtual": {                        // PERSISTIDA (sobrevive a reload/queda de energia)
    "id": "uuid-ou-timestamp",
    "iniciadaEm": "2026-06-12T10:00:00.000Z",
    "finalizada": false,                     // true bloqueia nova finalização (sem duplicar)
    "respostas": {
      "12": {
        "marcado": {
          "idsOriginais": ["C"],             // FONTE para correção/histórico (IDs ORIGINAIS;
                                             //  em V-F/select/arrastar: a estrutura por id/valor)
          "letrasVisuais": ["A"]             // OPCIONAL — só exibição/auditoria da tentativa
        },
        "revelado": true,
        "acerto": false,                     // null = revelada sem auto-avaliação (não conta)
        "tempoMs": 43000                     // tempo de foco visível até revelar, acumulado
      }
    }
  },
  "porQuestao": {
    "12": { "tentativas": 3, "acertos": 1, "erros": 2,
            "ultimoResultado": "erro", "ultimos": ["acerto","erro","erro"],
            "dominio": "reforcar" }
  },
  "historico": [
    { "data": "...", "tentativaId": "...", "total": 250, "respondidas": 250, "acertos": 180,
      "erros": 70, "naoRespondidas": 0, "duracaoMs": 1830000, "tempoQuestaoMs": 41000,
      "porTipo": { "marcar_uma": {"ok":50,"err":10} }, "porCaso": { "Contoso": {"ok":3,"err":1} },
      "tempoTipo": { "marcar_uma": {"ms": 600000, "n": 60} }, "erradas": [12, 34, 90] }
  ]
}
```

Regras de comportamento:
- **Tentativa atual persistente:** cada marcação/revelação/auto-avaliação é salva imediatamente;
  recarregar a página/fechar o navegador **continua a tentativa**. Tentativa `finalizada:true`
  encontrada no boot → inicia automaticamente uma nova tentativa (histórico já está salvo).
- **Finalizar sem duplicar:** com `tentativaAtual.finalizada:true`, clicar de novo em "Finalizar"
  não grava outra entrada no histórico.
- **`autograde:false`:** a questão só é contabilizada quando o usuário marca **Acertei/Errei**
  (`acerto:null` = não conta; o resumo mostra "Sem auto-avaliação").
- **Domínio por questão** (recalculado ao finalizar): `novo` = 0 tentativas; `dominado` = ≥3
  tentativas, **últimas 3 corretas** e taxa ≥80%; `reforcar` = última errada OU taxa de erro ≥50%
  com ≥2 tentativas; `em_aprendizado` = demais com ≥1 tentativa.
- **Tempo por questão:** o template registra quando a questão entra em **foco visível**
  (IntersectionObserver) e quando a resposta é **revelada**; `tempoMs` é a diferença acumulada por
  `seq` na tentativa atual.
- **Compatibilidade:** dados sem `versao` são tratados como **v1 e migrados em memória** ao
  carregar (preserva `porQuestao`/`historico`). `idsOriginais` é a fonte de correção/histórico;
  `letrasVisuais` é opcional. Exportar/Importar JSON continua funcionando (import migra v1→v2).
  Botões separados: **Limpar tentativa atual** × **Limpar TODO o histórico**. Tudo offline,
  sem servidor e sem CDN.

## Página de estatísticas (motor de revisão direcionada)

Objetivo: sair de "como fui nessa tentativa?" para **"o que eu preciso estudar agora?"**.

Visão dedicada (`#statsView`) com **escopo selecionável**: **Tentativa atual** × **Acumulado
(histórico)** (rádio no topo). Componentes:
1. **KPIs:** Respondidas, Acertos, Erros, % de acerto, **Tempo**, **Não respondidas**,
   **Tempo médio/questão** e "Sem auto-avaliação" (escopo atual); "Acerto em divergentes";
   no acumulado: Tentativas, Melhor %, % médio.
2. **Revisão direcionada (botões que abrem uma sessão filtrada no quiz, com barra "Sair da revisão"):**
   - `Revisão prioritária`: erro na tentativa atual ∪ taxa de erro ≥50% ∪ ≥2 erros ∪ baixa
     confiança ∪ divergência — **excluindo questões `dominado`**;
   - `Estudar erradas` (tentativa atual ∪ histórico); `Estudar não respondidas`;
   - `Estudar baixa confiança` (`confianca ∈ {baixa, muito_baixa}`); `Estudar divergências`
     (`concordante:false`); `Estudar "reforçar"` (domínio); `Estudar pior tipo`; `Estudar pior caso`.
3. **Resumo de domínio:** contagem de questões por estado (`novo`/`em_aprendizado`/`reforcar`/`dominado`).
4. **Tabela "Desempenho por tipo"**: Respondidas, Acertos, Erros, % de acerto, **tempo médio** e
   barra de desempenho (verde ≥70 / âmbar ≥40 / vermelho), ordenada do pior para o melhor.
5. **Gráficos (Chart.js local):** rosca acertos×erros; barra **% por tipo**; barra empilhada;
   linha de **evolução geral** entre tentativas; linha de **evolução POR TIPO** entre tentativas.
6. **Desempenho por estudo de caso** (tabela) e **por confiança dos agentes** + comparativo
   **divergentes × não divergentes**.
7. **Questões mais erradas (histórico)** com "Ir à questão"; **questões com tempo alto e erro**
   (tentativa atual).
8. **Foco de estudo:** os 2–3 tipos com menor acerto.

**Tempo:** `historico[].duracaoMs` = duração da tentativa (de `iniciadaEm` até Finalizar);
`tempoQuestaoMs` = tempo médio por questão; `tempoTipo` = custo de tempo por tipo.
**Reiniciar**/**Limpar tentativa atual** zeram a tentativa e o cronômetro (mantêm o histórico).

## Não-funcionais

- HTML/CSS/JS **puro**, sem framework, sem build, sem rede. Layout limpo e legível, responsivo o
  suficiente para desktop. Acessível por teclado nos controles.
- Tudo em **PT-BR** na interface (rótulos, botões, mensagens).
- Robusto a campos ausentes (questão sem imagem, sem caso, etc.).
- Carregar rápido mesmo com 200+ questões (renderizar só a página de 50 ativa).
