# Referência — Tipos de questão (8 tipos) e captura

Oito tipos. Cada questão recebe um `tipo` na coleta. Isso define o controle no **simulado**, o
documento Word de destino e como capturar a resposta.

| `tipo` | Descrição | Resposta/opções em imagem? | Documento Word |
|---|---|---|---|
| `marcar_uma` | marcar **uma** opção (radio) | não | `Questões.docx` |
| `multipla` | múltipla escolha (checkboxes; "cada correta vale 1 ponto") | não | `Questões.docx` |
| `arrastar` | arrastar opção → caixa; a **mesma opção pode repetir** | **sim** | `Arrastar e Combobox.docx` |
| `select` | um ou mais `<select>`/combobox para escolher o correto | **sim** | `Arrastar e Combobox.docx` |
| `hotspot_imagem` | imagem visual; dizer qual **botão/área** marcar | **sim** (a imagem) | `Arrastar e Combobox.docx` |
| `sim_nao` | "Isso atende ao objetivo?" Sim/Não | não | `Sim ou Não.docx` |
| `verdadeiro_falso` | normalmente **3 afirmações** julgadas V/F | **sim** (grade) | `Verdadeiro ou Falso.docx` |
| `estudo_caso` | questão ligada a um cenário/caso (herda o tipo interno) | herda | `Estudo de caso - <Nome>.docx` |

## Detecção (heurísticas)

- **`sim_nao`**: opções literais Sim/Não (Yes/No) + "Isso atende ao objetivo?/Does this meet the goal?".
- **`verdadeiro_falso`**: várias afirmações com colunas Sim/Não ou Verdadeiro/Falso (avalia veracidade).
- **`arrastar`**: "ARRASTAR E SOLTAR"/"DRAG AND DROP"; há **origem** (banco de opções) e **alvos** (caixas).
- **`select`**: a área de resposta tem `<select>`/dropdowns ("selecione na lista").
- **`hotspot_imagem`**: a questão exibe uma **imagem** e pede para apontar um ponto/botão/área.
- **`multipla`**: pede "selecione N" / "cada resposta correta apresenta parte da solução" (checkbox).
- **`marcar_uma`**: uma única alternativa correta (radio). É o padrão quando nada acima se aplica.
- **`estudo_caso`**: a questão pertence a um cenário com menu lateral (Business requirements,
  Existing environment, etc.). **Prioridade de agrupamento**: vai para o doc do caso, mesmo que
  internamente seja `marcar_uma`, `select`, etc. Registre o tipo interno em `tipo_interno`.

Use `tipo: "indefinido"` se não der para classificar com segurança e sinalize no QA.

## Captura por tipo (regra de imagens)

Para `arrastar`, `select`, `verdadeiro_falso` e `hotspot_imagem`, **as opções/respostas costumam
ser imagens** no secexams. Portanto:

1. **Capture a imagem exata** (screenshot do elemento — ver `operacao-site.md`):
   - `arrastar`/`select`: imagem do conjunto de opções/alvos → `opcoes_img`.
   - `verdadeiro_falso`: imagem da grade de afirmações/respostas → `opcoes_img`.
   - `hotspot_imagem`: imagem do enunciado/figura → `enunciado_img` (+ `hotspots[]`; `bbox` é
     **opcional** e, quando preenchido, deve ser **relativo** à imagem — `{x,y,w,h,unit:"relative"}`
     com valores 0..1. Com `bbox` o simulado usa overlay clicável; sem `bbox`, fallback por
     botões rotulados — a ausência **não bloqueia** a geração).
   - resposta revelada do site, se for imagem → `resposta_site_img`.
2. **Transcreva para texto** (preenche `opcoes/alvos/banco_opcoes/afirmacoes` e os `*_en`): é o que
   permite **correção automática** no simulado, o **relatório de divergências** e os **Word**.
3. Capture **exatamente** as opções possíveis — inclusive repetições válidas no `arrastar`
   (a mesma opção pode ser usada em mais de um alvo).

## Resposta estruturada por tipo (entra em `resposta_correta`/`resposta_site`)

| `tipo` | Estrutura |
|---|---|
| `marcar_uma` | `{ "letra": "C" }` |
| `multipla` | `{ "letras": ["A","C"] }` |
| `sim_nao` | `{ "valor": "Yes" }` (ou `"No"`) |
| `verdadeiro_falso` | `{ "afirmacoes": { "s1": true, "s2": false, "s3": false } }` |
| `select` | `{ "selecoes": { "t1": "o3", "t2": "o1" } }` (alvo → id da opção) |
| `arrastar` | `{ "mapeamento": { "t1": ["o2"], "t2": ["o1","o1"] } }` (repetição permitida) |
| `hotspot_imagem` | `{ "hotspot": "h2" }` (ou lista, se múltiplos pontos) |
| `estudo_caso` | usa a estrutura do `tipo_interno` |

> A `resposta_correta` é sempre derivada do **inglês original** (texto transcrito). No simulado o
> destaque/seleção correta é renderizado no idioma atual (PT por padrão; EN no toggle).
