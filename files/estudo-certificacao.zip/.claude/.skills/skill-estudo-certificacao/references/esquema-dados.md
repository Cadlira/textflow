# Referência — Esquema de dados compartilhado (`questions.json`)

Um único arquivo `<saída>\_work\questions.json` é a **fonte de verdade** que alimenta os **Word**
e o **simulado**. Lista de objetos-questão, na **ordem exata do site** (`seq` crescente).

## Objeto-questão

```jsonc
{
  "seq": 1,                       // ORDEM exata no site (1..N) — o simulado segue isto
  "numero": "1",                  // número exibido pelo site (string), se houver
  "pagina": 1,                    // bloco de 50 (1 = questões 1..50)

  "tipo": "marcar_uma",           // o CONTROLE REAL da questão (marcar_uma, multipla, select, ...)
                                  // — vale também para questões de estudo de caso
  "tipo_interno": null,           // reservado para compatibilidade; desnecessário se `tipo` já
                                  // guarda o controle real (não preencher em dados novos)

  "caso": null,                   // AGRUPADOR VISUAL: nome do estudo de caso (ex.: "Fabrikam") ou null
  "contexto_en": null,            // cenário/requisitos do caso (inglês), com subtítulos preservados
  "contexto_pt": null,            // tradução limpa do contexto (texto estruturado)

  "enunciado_en": "...",          // enunciado ORIGINAL em inglês
  "enunciado_pt": "...",          // tradução PT-BR limpa (feita pela IA)
  "enunciado_img": null,          // "img/q001-enunciado.png" se a questão tem imagem (hotspot)

  // marcar_uma | multipla | sim_nao
  "opcoes": [
    { "id": "A", "texto_en": "...", "texto_pt": "...", "img": null }
  ],

  // verdadeiro_falso
  "afirmacoes": [
    { "id": "s1", "texto_en": "...", "texto_pt": "..." }
  ],

  // arrastar | select
  "alvos": [ { "id": "t1", "rotulo_en": "...", "rotulo_pt": "..." } ],
  "banco_opcoes": [ { "id": "o1", "texto_en": "...", "texto_pt": "...", "img": null } ],
  "opcoes_img": null,             // "img/q010-opcoes.png" — imagem fiel do conjunto de opções

  // hotspot_imagem — bbox é OPCIONAL e, quando existir, RELATIVO (proporção 0..1 da imagem)
  "hotspots": [
    { "id": "h1", "rotulo_pt": "Botão Salvar", "rotulo_en": "Save button",
      "bbox": { "x": 0.12, "y": 0.20, "w": 0.18, "h": 0.08, "unit": "relative" } }
  ],
  // Com bbox relativo → o simulado renderiza áreas clicáveis sobre a imagem.
  // Sem bbox → fallback por botões rotulados (a ausência NÃO bloqueia a geração).
  // bbox legado em pixels ([x,y,w,h]) é descartado pelo build → fallback por botões.

  // gabarito do SITE (estruturado por tipo) + imagem da resposta revelada, se for imagem
  "resposta_site": { "letra": "B" },
  "resposta_site_img": null,

  // VERDADE dos agentes (estruturada por tipo; textos em EN)
  "resposta_correta": { "letra": "C" },
  "concordante": true,            // resposta_correta == resposta_site ?
  "confianca": "alta",            // "muito_baixa"|"baixa"|"media"|"alta"|"muito_alta" (muito_baixa/baixa => vai à mesa)
  "revisada_mesa": false,         // true após a mesa-decisao revisar (divergência/baixa confiança)
  "justificativa_pt": "...",      // MOTIVO — obrigatório para TODAS as questões
  "fontes": ["https://learn.microsoft.com/..."]
}
```

## Estrutura de `resposta_site` / `resposta_correta` por tipo

| `tipo` | Estrutura |
|---|---|
| `marcar_uma` | `{ "letra": "C" }` |
| `multipla` | `{ "letras": ["A","C"] }` |
| `sim_nao` | `{ "valor": "Yes" }` |
| `verdadeiro_falso` | `{ "afirmacoes": { "s1": true, "s2": false, "s3": false } }` |
| `select` | `{ "selecoes": { "t1": "o3", "t2": "o1" } }` |
| `arrastar` | `{ "mapeamento": { "t1": ["o2"], "t2": ["o1","o1"] } }` |
| `hotspot_imagem` | `{ "hotspot": "h2" }` |

## Arquivos auxiliares em `_work\`

### Veredictos — convenção obrigatória de nomes
```text
_work/verdicts-exame-001-018.json     # 1º agente (pesquisador-verificador)
_work/verdicts-produto-001-018.json   # 2º agente (pesquisador-documentacao-produto)
_work/verdicts-consenso-001-018.json  # aceitos pelo compare-verdicts.js
_work/verdicts-mesa.json              # decisões da mesa (revisada_mesa:true)
```
**Não criar** novos arquivos no formato antigo `verdicts-001-018.json` — esse nome só existe por
legado e o `merge.js` o trata como veredito de exame com a **menor** precedência. Precedência do
merge: `mesa > consenso > produto > exame > legado`.

### Auditoria de consenso — `analises-consenso.json` (gerado pelo `compare-verdicts.js`)
Guarda a deliberação interna dos dois agentes e **NUNCA entra no `questions.json`** (que continua
limpo, só com a decisão final consumida por Word/simulado). Conteúdo por questão: veredito do
agente de exame, veredito do agente de produto, status de consenso (`concordam`/`conflito`/
`estrutura_incompativel`/`incompleto`), motivo, indicação se foi para a mesa e confiança final
calculada antes da mesa. No topo: listas `aceitas`, `mesa` e `pendentes_segundo_agente`.
O `questions.json` recebe apenas: `resposta_correta`, `concordante`, `confianca`, `revisada_mesa`,
`justificativa_pt`, `fontes` e os campos traduzidos/estruturados de exibição.

### Traduções — `traducoes-<inicio>-<fim>.json` (gerado pelo `tradutor-ptbr`)
Objeto **keyed por `seq`**, contendo **apenas campos `*_pt`** (ver `agents/tradutor-ptbr.md`):
`enunciado_pt`, `contexto_pt`, `opcoes[].texto_pt`, `afirmacoes[].texto_pt`, `alvos[].rotulo_pt`,
`banco_opcoes[].texto_pt`, `hotspots[].rotulo_pt`. Aplicado no `questions.json` por
`tools/apply-traducoes.js` (que **nunca** altera `resposta_correta`, `resposta_site`,
`concordante`, `confianca`, `revisada_mesa`, `justificativa_pt` ou `fontes`). O gate
`tools/validate-ptbr.js` **reprova** Word/simulado com `*_pt` ausente.

### Estudos de caso (fallback) — `casos.json`
Quando o DOM não permitir detectar estudo de caso com segurança, criar manualmente:

```json
{
  "Contoso":  { "seq_inicio": 87, "seq_fim": 94,  "contexto_en": "...", "contexto_pt": "..." },
  "Fabrikam": { "seq_inicio": 95, "seq_fim": 101, "contexto_en": "...", "contexto_pt": "..." }
}
```

Se existir, o `merge.js` (e o build) aplica `caso` + contexto às questões dentro das faixas antes
de gerar simulado e Word — correção manual controlada, sem depender do DOM.

## Regras

- **Idiomas:** `*_en` = original do site; `*_pt` = tradução limpa da IA (**`tradutor-ptbr`** via
  `traducoes-*.json` + `apply-traducoes.js`; scripts não traduzem). O simulado usa PT por
  padrão e alterna para EN; os Word usam PT na pergunta e `resposta_correta` em **inglês**.
- **Imagens:** caminhos relativos a partir da pasta do simulado (`img/...`). Os arquivos físicos
  ficam em `<saída>\simulado\img\`; o redator de Word referencia os mesmos arquivos.
- **`justificativa_pt` é obrigatória em todas** (alimenta o "motivo" do simulado).
- **`seq` é único e contínuo**; o simulado e a paginação 50/pág dependem dele.
- Campos não aplicáveis ao tipo ficam ausentes ou `null` (não invente).
- Validação mínima antes de gerar saídas: todo objeto tem `seq`, `tipo`, `enunciado_en`,
  `resposta_correta`, `concordante`, `justificativa_pt`.
