# Referência — Formato de saída (Word + `Divergências.md`)

Baseado nos exemplos reais em `Desktop\Certificações\IA\AB-100\`. Os Word são gerados pelo
**Redator-documentos** a partir de `_work\questions.json` (esquema em `esquema-dados.md`).

## Princípios (todos os Word)

- **Pergunta + opções/alvos/afirmações:** em **PT-BR limpo** (`*_pt`). Os `*_pt` vêm do
  **`tradutor-ptbr`** (aplicados por `tools/apply-traducoes.js`); **gate obrigatório** antes de
  gerar: `node tools/validate-ptbr.js <codigo>` aprovado (o fallback EN do `gen-word.py` é só
  proteção técnica — entrega final com campo em inglês é REPROVADA pelo QA).
- **`Resp:`** = resposta correta dos agentes (`resposta_correta`), em **inglês** (texto exatamente
  como no site) — para reconhecer a opção certa na prova real.
- **Documentos limpos:** sem justificativa/fontes (isso só no `Divergências.md` e no simulado).
- A `Resp:` vem **abaixo** da pergunta. Numeração = `numero`/`seq` do site (não renumerar).
- **Tipos com imagem** (`arrastar`, `select`, `verdadeiro_falso`, `hotspot_imagem`): inserir a
  **imagem capturada** (`opcoes_img`/`enunciado_img`, de `simulado/img/`) **e** a transcrição em
  texto; a `Resp:` usa a transcrição em inglês.
- **`opcoes_img` é obrigatória no Word sempre que existir**, inserida **antes** da transcrição
  textual: em `verdadeiro_falso`, a grade original antes das afirmações; em `arrastar`/`select`,
  a imagem dos alvos/opções antes da lista transcrita (o `tools/gen-word.py` aplica isso; não
  duplica quando `opcoes_img` == `enunciado_img`).
- **`resposta_site_img` NÃO entra nos Word limpos por padrão** — só pode aparecer em material de
  auditoria/divergências, nunca no material de estudo.
- **Geração física:** os `.docx` são gerados por **`python tools/gen-word.py <codigo>`**
  (pré-requisito `python-docx`); não montar Word à mão nem depender de skill externa de docx.

## Arquivos (em `<saída>\`)

| Arquivo | Tipos |
|---|---|
| `Questões.docx` | `marcar_uma`, `multipla` |
| `Sim ou Não.docx` | `sim_nao` |
| `Verdadeiro ou Falso.docx` | `verdadeiro_falso` |
| `Arrastar e Combobox.docx` | `arrastar`, `select`, `hotspot_imagem` |
| `Estudo de caso - <Nome>.docx` | `estudo_caso` (um por caso) |
| `Divergências.md` | só `concordante:false` |

## Templates

**`marcar_uma` / `multipla`** (`Questões.docx`)
```
Q<seq>. <enunciado PT>
A. <opção PT>   B. ...   C. ...   D. ...

Resp: <letra(s)> — <texto da(s) opção(ões) em INGLÊS>
```

**`sim_nao`** (`Sim ou Não.docx`)
```
Q<seq>. <cenário/solução PT> ... Isso atende ao objetivo?
A. Sim   B. Não

Resp: <Yes | No>
```

**`verdadeiro_falso`** (`Verdadeiro ou Falso.docx`) — normalmente 3 afirmações
```
Q<seq>. <enunciado PT>
[imagem da grade: opcoes_img]
1. <afirmação 1 PT>
2. <afirmação 2 PT>
3. <afirmação 3 PT>

Resp: Statement 1: Yes; Statement 2: No; Statement 3: No
```

**`arrastar` / `select`** (`Arrastar e Combobox.docx`)
```
Q<seq>. [ARRASTAR E SOLTAR | HOTSPOT] <enunciado PT>
[imagem fiel das opções: opcoes_img]
Alvos (PT): <lista de alvos>     Opções (PT): <banco de opções>

Resp:
- <Alvo 1> → <opção em INGLÊS>
- <Alvo 2> → <opção em INGLÊS>   (repetir se a mesma opção for usada mais de uma vez)
```

**`hotspot_imagem`** (`Arrastar e Combobox.docx`)
```
Q<seq>. <enunciado PT>
[imagem do enunciado: enunciado_img]

Resp: <descrição em INGLÊS do botão/área correta (hotspots[].rotulo)>
```

**`estudo_caso`** (`Estudo de caso - <Nome>.docx`)
```
[Título: Estudo de caso - <Nome>]
<bloco de contexto PT (contexto_pt) — uma vez>
----------------------------------------
Q<seq>. <enunciado PT + controle conforme tipo_interno>
Resp: <resposta em INGLÊS no formato do tipo_interno>
```
> Questão de caso fica **dentro** do doc do caso (não duplicar nos docs por categoria). Aplica o
> template do `tipo_interno` (incl. imagens se for tipo-imagem).

## `Divergências.md`
```markdown
# Divergências — <CÓDIGO> (<data>)
| # (seq) | Tipo | Resposta do site | Resposta correta (IA) | Justificativa | Fontes |
|---|---|---|---|---|---|
| 12 | marcar_uma | B — <EN> | C — <EN> | <1-2 frases> | <link learn> |
```
Sem divergências: `Nenhuma divergência — a IA concordou com o gabarito do site nas N questões.`

## Estilo
- `Q<seq>.` e `Resp:` em **negrito**; conteúdo normal. Uma quebra entre questões.
- Imagens redimensionadas para caber na página (largura ~15 cm). Nomes de arquivo exatamente como na tabela (com acentos).
