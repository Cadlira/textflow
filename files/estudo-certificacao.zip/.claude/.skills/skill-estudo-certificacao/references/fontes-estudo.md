# Referência — Fontes de estudo e como decidir a resposta correta

Guia para o **Pesquisador-verificador** (exame) e o **Pesquisador-documentação-produto**.
O gabarito do site é uma **hipótese a verificar**, não verdade absoluta — bancos de simulado
erram. Decida a resposta **de forma independente** e só então compare.

## 1. Descobrir a página oficial do exame (Microsoft Learn)

A partir do código do exame (ex.: `ab-730`):
1. Busque na web: `Microsoft certification exam <código> study guide site:learn.microsoft.com`
   ou `<código> exam learn.microsoft.com`.
2. A página canônica costuma estar em
   `https://learn.microsoft.com/credentials/certifications/...` (com o **Study guide** do exame)
   e nos módulos de `https://learn.microsoft.com/training/...`.
3. Guarde a URL do **Study guide** e os módulos de treino — são a fonte primária e devem ser
   citados nas `fontes` dos vereditos.

> Observação: códigos do secexams podem não bater 1:1 com o código oficial Microsoft. Pelo
> conteúdo das questões (ex.: Copilot Studio, Dynamics 365, Microsoft Foundry, Power Platform),
> identifique o exame oficial correspondente e use o study guide dele.

## 2. Hierarquia de confiança das fontes

1. **Microsoft Learn** (study guide, docs de produto, módulos de treino) — fonte primária.
2. Documentação oficial Microsoft de produto (`learn.microsoft.com/<produto>`).
3. `support.microsoft.com` (oficial — ver regra abaixo).
4. Blogs oficiais Microsoft / Tech Community (apenas apoio).
5. Fontes secundárias confiáveis (somente para desempate; nunca como única base).

Evite tratar outros sites de "dump" como verdade — eles repetem os mesmos erros do simulado.

### Documentação oficial por produto (foco do 2º agente)
Para questões de recurso, licença, limite, tela, permissão, integração ou comportamento
específico, a fonte decisiva é a documentação do **produto citado na questão**:
`learn.microsoft.com/microsoft-365-copilot`, `learn.microsoft.com/copilot-studio`,
`learn.microsoft.com/power-platform`, `learn.microsoft.com/dynamics365`,
`learn.microsoft.com/azure`, `learn.microsoft.com/entra`, `learn.microsoft.com/graph`,
`support.microsoft.com` e equivalentes. A documentação pode variar por **data, região, licença
ou plano** — registrar essas condições quando relevantes.

### Regra do `support.microsoft.com` (fixa)
- Conta como **fonte oficial Microsoft**, mas **NUNCA sozinho** para confirmar divergência contra
  o gabarito do site.
- Para confirmar divergência: **≥2 fontes oficiais**, sendo **ao menos uma**
  `learn.microsoft.com` ou documentação oficial de produto equivalente;
  `support.microsoft.com` pode ser a **segunda** fonte quando complementar e consistente.
- Tech Community e blogs oficiais podem apoiar, mas **não substituem** documentação oficial para
  derrubar o site.

## 3. Procedimento por questão

1. Entenda o que a questão pede (em inglês, termos exatos dos produtos).
2. Levante a resposta candidata com base no Microsoft Learn (cite a passagem/URL).
3. Compare com `resposta_marcada_site`:
   - **Iguais** → `concordante: true`. Justificativa curta + fonte.
   - **Diferentes** → **aprofunde**: busque uma 2ª fonte oficial que confirme; só então crave
     `resposta_correta_EN` e marque `concordante: false`.
4. Para múltipla seleção (hotspot/arrastar), verifique **cada** pareamento/seleção individualmente.

## 4. Saída por questão (entra em `verdicts.json`)

```json
{
  "numero": 12,
  "tipo": "multipla_escolha",
  "resposta_site_EN": "B — <texto>",
  "resposta_correta_EN": "C — <texto>",
  "concordante": false,
  "justificativa": "<1-2 frases objetivas, em PT-BR, citando o conceito>",
  "fontes": ["https://learn.microsoft.com/..."]
}
```

Regras:
- `resposta_correta_EN` **sempre em inglês** (texto exatamente como a opção aparece no site).
- `justificativa` curta e objetiva (vai para o `Divergências.md`, não para os `.docx`).
- `fontes`: pelo menos 1 URL oficial; em divergência, idealmente 2.
- Em caso de **incerteza genuína** após estudo, marque `concordante` conforme a melhor evidência
  e registre a dúvida na `justificativa` (não invente certeza).
