Use a skill `skill-estudo-certificacao` para iniciar o fluxo completo de estudo de certificação do secexams.com.

Se `$ARGUMENTS` contiver um código de exame, use esse código. Se estiver vazio, pergunte apenas o código do exame.

Depois siga a skill ponta a ponta: abrir/usar o Chrome com CDP, aguardar login quando necessário, coletar questões, verificar respostas, traduzir, gerar Word, Divergências.md, simulado offline e QA.
